# Smart-X Network Monitoring and Management System

**Course:** Programming 3B (PROG7312)  
**Student:** Lindokuhle Mbatha  
**Framework:** .NET 10  
**Client:** Windows Forms  
**Backend:** ASP.NET Core Web API

## 1. Project structure

```text
SystemXsystem/
├── SystemXsystem.sln
├── SystemXsystem_API/          # ASP.NET Core API and data-processing services
│   ├── Controllers/
│   ├── Models/
│   └── Services/
├── SystemXsystem_API.Tests/    # Dependency-free regression/performance test runner
├── Documentation/              # Implementation, competition, learning and recommendation reports
└── SystemXsystem1/             # Windows Forms desktop client
    ├── ApiClient.cs
    ├── MainForm.cs
    ├── DashboardPanel.cs
    ├── IngestionPanel.cs
    ├── CommandPanel.cs
    └── TopologyPanel.cs
```

## 2. Requirements

- Windows 10 or Windows 11 (the graphical client uses Windows Forms).
- .NET 10 SDK installed.
- Visual Studio 2022/2026 with the **.NET desktop development** and **ASP.NET and web development** workloads, or the .NET CLI.

Check the SDK installation in PowerShell:

```powershell
dotnet --list-sdks
```

The output must include a `10.0.xxx` SDK. A runtime alone is not sufficient to build the projects.

## 3. Run the application

### Option A: Use the launcher

Double-click `Run-SmartX.bat` in this folder. It opens the API in a separate terminal and then starts the Windows Forms client.

### Option B: Run manually

1. Open PowerShell in the `SystemXsystem` folder.
2. Start the API:

   ```powershell
   dotnet run --project .\SystemXsystem_API\SystemXsystem_API.csproj
   ```

3. Wait for the API to report that it is listening on `http://localhost:5000`.
4. In a second PowerShell window, return to the same folder and start the client:

   ```powershell
   dotnet run --project .\SystemXsystem1\SystemXsystem1.csproj
   ```

5. The client should show **Connected** in its top bar. Its default API URL is `http://localhost:5000`.
6. To run the telemetry-history regression tests, use a third PowerShell window:

   ```powershell
   dotnet run --project .\SystemXsystem_API.Tests\SystemXsystem_API.Tests.csproj
   ```

The API seeds eight demonstration devices on startup. The Dashboard also retains a **Load demo devices** button; seeding is safe to repeat because existing device IDs are not registered twice.

## 4. Verify the API

Open this address in a browser while the API is running:

```text
http://localhost:5000/api/health
```

A successful response contains `"success": true` and the number of registered demonstration devices. The root address `http://localhost:5000/` also returns a short service status response.

## 5. Application modules

- **Dashboard:** online-device count, active alerts, queue lengths, notifications and automated insights. Includes a telemetry simulator.
- **Sensor Ingestion:** register devices, submit readings, trigger critical samples and view the sensor timeline.
- **Command Stream:** search for devices, send ON/OFF commands to actuators and undo the most recent command.
- **Network Topology:** visualises the gateway, zones and devices, with status indicators. Includes BFS, DFS and Prim MST actions.
- **Historical telemetry:** Sensor Ingestion provides From/To date pickers for UTC-bounded history queries.

## 6. Data structures demonstrated

| Data structure | Use in the application |
|---|---|
| `Dictionary<string, Device>` | Fast lookup of registered devices by node ID/MAC address. |
| `TelemetryHistoryIndex` (AVL trees) | Chronological telemetry history, with one global AVL index and one per-device AVL index for date-range queries. |
| `Queue<TelemetryPacket>` | FIFO processing of normal telemetry. |
| `PriorityQueue<TelemetryPacket, int>` | Critical telemetry is processed before normal queued readings. |
| `Stack<CommandLog>` | Stores command history for undo operations. |
| `HashSet<string>` | Tracks unique active error/disconnected node IDs. |
| `NetworkTreeNode` | Explicit gateway → zone → device tree. |
| `NetworkGraph` | Vertices and weighted edges for topology algorithms. |
| `Queue<string>` / `Stack<string>` | BFS and DFS graph traversal worklists. |
| `PriorityQueue<NetworkEdge, (double, long)>` | Selects the lowest composite-cost frontier edge in Prim's MST, with deterministic tie-breaking. |

The graph service calculates a dimensionless edge cost: `0.50 × (energy mJ / 100) + 0.30 × (latency ms / 200) + 0.20 × (packet-loss % / 100)`. Inputs are bounded before scoring. Signal strength is returned as diagnostic information, while its practical effect is represented through measured latency and packet loss. Prim minimises the sum of these edge costs and reports total selected-link energy plus average latency and packet loss.

The in-memory store protects shared collection access with a common lock because the API controllers and background telemetry worker access the same data. The AVL history index keeps equal timestamps distinct with a monotonically increasing sequence number. Its range query traverses the selected global or per-device tree from newest to oldest, stops after collecting the requested number of matches, and returns those matches in chronological order. Insertions and removals are O(log n); a bounded range query is O(log n + k), where k is the number of returned records. The store retains up to 100,000 readings and evicts the oldest reading when the limit is exceeded.

## 7. Suggested demonstration sequence

1. Start the API and desktop client; show the Connected status and seeded dashboard.
2. Open **Sensor Ingestion** and select **Moisture Sensor A**.
3. Send a normal reading such as `55`; explain that it enters the FIFO queue and appears in the history chart.
4. Send a critical sample; explain that the reading is routed through the priority queue and creates an alert.
5. Return to **Dashboard** and show the alert, notification and suggested action.
6. Open **Command Stream**, select an actuator such as Pump A, send `ON`, then use **Undo** and show the previous state being restored.
7. Search for a device by name or zone.
8. Open **Network Topology** and explain the gateway → zone → device hierarchy and status colours.
9. Start the dashboard simulation briefly to show telemetry updating automatically.

## 8. New topology and history API endpoints

- `GET /api/topology/algorithms/tree` — explicit gateway/zone/device tree.
- `GET /api/topology/algorithms/graph` — graph vertices and weighted edges.
- `GET /api/topology/algorithms/traverse?startNode=gateway&method=BFS` — BFS traversal; use `method=DFS` for depth-first traversal.
- `GET /api/topology/algorithms/mst` — Prim minimum spanning tree (or forest if disconnected), including total composite cost, selected-link energy and average link quality metrics.
- `GET /api/telemetry/history?deviceId=...&fromUtc=...&toUtc=...&take=5000` — historical range query.

The Topology screen includes buttons for BFS, DFS and MST. The MST status line displays selected-link count, composite cost, total energy and average latency. The Sensor Ingestion screen includes From/To date pickers and a Query range button.

## 9. Important implementation notes and limitations

- The topology view displays the gateway/zone/device hierarchy and the API builds a weighted graph for BFS, DFS and Prim MST. Routing cost is a normalised composite of estimated/measured energy cost (50%), latency (30%) and packet loss (20%); lower is better. `NetworkEdge` exposes the component metrics and `UsesSimulatedMetrics` flag. Device records can supply `EnergyCostMilliJoules`, `LinkLatencyMs`, `PacketLossPercent` and `SignalStrengthDbm`. Missing values use documented demo defaults and are explicitly marked simulated. The seeded demonstration therefore proves cost-aware algorithm behaviour, not real-world radio optimisation; physical ESP32 measurements must be integrated before making that claim.
- The Insight Engine combines recorded operator actions, simple three-reading trend checks and predefined rules. It is a rule/pattern-based suggestion engine, not a trained machine-learning model or LLM.
- Device records, telemetry history, notifications and command history are held in memory. They reset when the API process restarts; persistent database storage is a future enhancement.
- The desktop client is Windows-only because it uses Windows Forms.
- The API listens on `http://localhost:5000` by default. If this port is already occupied, stop the other process using it before starting the API.

## 10. Architecture overview

```mermaid
flowchart LR
    subgraph Desktop[Windows Forms desktop client]
        MF[MainForm / navigation]
        DB[Dashboard]
        SI[Sensor Ingestion]
        CS[Command Stream]
        NT[Network Topology]
        MF --> DB
        MF --> SI
        MF --> CS
        MF --> NT
    end
    subgraph API[ASP.NET Core Web API]
        C[API Controllers]
        DS[SmartXDataStore]
        TP[TelemetryProcessor]
        HI[TelemetryHistoryIndex / AVL]
        GS[NetworkGraphService]
        IE[InsightEngine]
        C --> DS
        DS --> HI
        TP --> DS
        C --> GS
        C --> IE
    end
    Desktop -->|Async HTTP| C
```

The desktop client is a presentation layer; the API owns application data and domain operations. The API uses singleton services for the in-memory store, insight engine and graph service, plus a hosted telemetry-processing worker. The diagram describes the current single-process demonstration architecture, not a deployed cloud topology.

## 11. Performance and algorithm complexity

| Operation | Expected complexity | Explanation |
|---|---:|---|
| Device dictionary lookup | O(1) average | Keyed lookup by device ID |
| AVL insert/remove | O(log n) | Height-balanced search tree |
| Bounded AVL range query | O(log n + k) expected | Navigate to range and visit only enough matching nodes for k results |
| BFS / DFS | O(V + E) | Each reachable vertex and edge is examined a bounded number of times |
| Prim with priority queue | O((V + E) log E) | Frontier edges are managed by a priority queue |
| FIFO queue / stack operations | O(1) | Enqueue/dequeue and push/pop |

The AVL history index maintains one global index and one index per device. This improves device-specific queries at the cost of extra index memory and two insertions per reading. The history store is capped at 100,000 records and remains in memory.

## 12. Verified build and regression evidence

The latest Criterion 2 project was built on the student's Windows environment using the .NET 10 SDK. The reported full-solution build succeeded for all three projects:

- `SystemXsystem1` (`net10.0-windows`)
- `SystemXsystem_API` (`net10.0`)
- `SystemXsystem_API.Tests` (`net10.0`)

The dependency-free regression runner reported **10/10 tests passed**:

1. Equal timestamps are retained.
2. Date boundaries are inclusive.
3. Device-specific index returns only that device.
4. Latest N results are returned chronologically.
5. Oldest entry can be evicted.
6. Large ordered insert and range query complete.
7. BFS and DFS visit each reachable node once.
8. Prim selects the lower composite-cost route.
9. Disconnected graph returns a minimum spanning forest.
10. Graph builder exposes link metrics and simulation flags.

The latest reported workload measurement was 50,000 inserts in 156 ms and a 100-result range query displayed as 0 ms (below the timer's millisecond display resolution). These are observations from one machine and one run, not repeatable performance guarantees. For a stronger benchmark, run multiple trials on the target machine and record hardware, SDK version, warm-up and median timings.

Automated tests do not replace manual integration checks. Before submission, also verify the desktop/API workflow described in `Documentation/FINAL_VERIFICATION_CHECKLIST.md`.

## 12. Documentation package

See the `Documentation` folder:

- `IMPLEMENTATION_REPORT.md` — architecture, data structures, tree, graph algorithms, history queries and verification plan.
- `PROJECT_COMPETITION_REPORT.md` — project concept, differentiators and demonstration story.
- `CHALLENGES_AND_LEARNINGS.md` — technical challenges and learning reflection prompts.
- `TECHNOLOGY_RECOMMENDATIONS.md` — scaling recommendations and rationale.
- `ITERATIVE_FEEDBACK_LEDGER.md` — traceability from identified improvement areas to source changes and verification evidence.
- `ARCHITECTURE.mmd` — editable Mermaid architecture diagram.
- `FINAL_VERIFICATION_CHECKLIST.md` — manual integration and submission checklist.

## 13. Troubleshooting

**Client shows Offline**
- Confirm the API terminal is still running.
- Check `http://localhost:5000/api/health` in a browser.
- Confirm the URL in the client is `http://localhost:5000` and press **Connect**.

**The `dotnet` command is not recognised**
- Install the .NET 10 SDK, not only the runtime.
- Close and reopen PowerShell or Visual Studio after installation.

**The app reports that the target framework is missing**
- Install the .NET 10 SDK and Windows Desktop Runtime for the Windows Forms client.

**Port 5000 is already in use**
- Stop the existing API instance or other process using port 5000, then restart the API.

## 14. Code structure and responsibilities

| File | Responsibility |
|---|---|
| `SystemXsystem_API/Program.cs` | Registers services, configures the API URL, seeds demo devices and exposes health information. |
| `Controllers/ApiControllers.cs` | Defines HTTP endpoints for devices, telemetry, commands, dashboard, insights and topology algorithms. |
| `Models/Models.cs` | Defines device, telemetry, command, notification, tree and graph data-transfer/domain models. |
| `Services/SmartXDataStore.cs` | Owns in-memory collections, validation, telemetry history, command undo and notifications. |
| `Services/TelemetryHistoryIndex.cs` | Implements the global and per-device AVL indexes, balancing rotations, range retrieval and oldest-record eviction. |
| `SystemXsystem_API.Tests/Program.cs` | Runs regression checks for equal timestamps, inclusive ranges, device isolation, latest-result ordering, eviction and a 50,000-record workload. |
| `Services/TelemetryProcessor.cs` | Background worker that processes queues and checks stale sensors. |
| `Services/InsightEngine.cs` | Generates rule-based and historical-pattern suggestions. |
| `Services/NetworkGraphService.cs` | Builds the network tree/weighted graph and implements BFS, DFS and Prim MST. |
| `SystemXsystem1/MainForm.cs` | Hosts the sidebar and integrates the four application modules. |
| `SystemXsystem1/ApiClient.cs` | Sends asynchronous HTTP requests and defines client-side response models. |
| `SystemXsystem1/IngestionPanel.cs` | Registers devices, submits readings and queries the telemetry timeline/date range. |
| `SystemXsystem1/TopologyPanel.cs` | Displays topology and invokes BFS, DFS and MST endpoints. |

## 15. Repository

Original repository link supplied with the project:

https://github.com/EMKNDN/emkndn-prog7312-g2-2026-prog7312-poe-lindoshandu07.git

For assessment, submit the repository URL itself and ensure the lecturer has access. A ZIP file does not preserve Git commit history.
