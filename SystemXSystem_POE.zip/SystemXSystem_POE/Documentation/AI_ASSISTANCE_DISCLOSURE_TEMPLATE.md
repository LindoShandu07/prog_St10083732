# AI Assistance Disclosure — Complete Only If Required by the Institution

Use this page only if the assessment instructions or institution require disclosure of AI assistance. Check the applicable academic-integrity policy and edit this statement so it accurately describes the assistance actually used. Do not submit an inaccurate declaration.

## Suggested disclosure structure

- **Tool(s) used:** [Name the tools actually used.] 
- **Purpose:** [For example: assistance with explaining compiler errors, reviewing documentation structure, suggesting test cases, or editing wording. Keep only activities that actually occurred.]
- **Student verification:** [Explain which generated suggestions were checked, modified, rejected or independently tested by you.]
- **Code ownership and understanding:** [Explain which code you personally implemented or adapted and confirm that you can explain the submitted implementation.] 
- **References/citations:** [Add citations or acknowledgement in the format required by your institution.]

AI-generated text or code should not be represented as personal experience or as a lecturer's feedback. The student remains responsible for verifying correctness, understanding the work and complying with institutional policy.
