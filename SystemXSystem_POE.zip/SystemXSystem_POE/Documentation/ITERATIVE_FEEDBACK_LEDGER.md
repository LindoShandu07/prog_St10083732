# Iterative Feedback Incorporation Ledger

**Project:** Smart-X Network Monitoring and Management System  
**Part:** Programming 3B (PROG7312), Part 3  
**Purpose:** Record engineering changes, source evidence and verification. This ledger distinguishes code changes evidenced in the current ZIP from exact lecturer comments that must be copied from the original feedback document.

> **Evidence limitation:** The current ZIP does not contain the original formative feedback PDF or a dated commit history. Therefore, the descriptions below are improvement themes visible in the project and Part 3 rubric, not verbatim quotations from the lecturer. Before submission, add the exact feedback wording and feedback date from the lecturer's document.

## Change ledger

| ID | Improvement theme / feedback area | Previous limitation evidenced in project history | Implemented change | Source evidence | Verification evidence | Remaining work |
|---|---|---|---|---|---|---|
| FB-01 | Efficient historical telemetry queries | Previous query filtered `SortedDictionary.Values` with LINQ, scanning history | Added generic AVL tree, global and per-device indexes, inclusive bounded range retrieval and oldest-entry removal | `SystemXsystem_API/Services/TelemetryHistoryIndex.cs`; `SmartXDataStore.cs` | Tests: duplicate timestamps, inclusive boundaries, device isolation, latest-N order, eviction, 50,000-record workload | Add repeated benchmark trials and concurrency tests |
| FB-02 | Correct timestamp ordering | Timestamp-only keys cannot uniquely represent multiple readings at the same instant | Added composite key `(UTC ticks, sequence)` without changing packet timestamps | `TelemetryHistoryIndex.cs` | Equal-timestamp regression test passes | Consider persistence-safe unique IDs if moved to a database |
| FB-03 | Explicit graph traversal | Graph must support reachability analysis, not only a visual hierarchy | Added graph adjacency traversal using BFS queue and DFS stack with visited set | `NetworkGraphService.cs` | BFS/DFS regression test passes | Add larger randomized graph and cycle tests |
| FB-04 | Meaningful MST edge weights | Fixed demonstration weights do not represent link quality or energy trade-offs | Added normalised energy/latency/packet-loss composite cost and simulated-metric flag | `NetworkGraphService.cs`; graph models | Prim lower-cost route test and metric/simulation test pass | Replace defaults with timestamped physical measurements before claiming real radio optimisation |
| FB-05 | Disconnected graph handling | A disconnected graph cannot have one spanning tree | Prim restarts for each unvisited component and reports a minimum spanning forest | `NetworkGraphService.cs` | Disconnected-graph regression test passes | Add more complex multi-component test cases |
| FB-06 | Unified application navigation | Four modules need a consistent single application shell | `MainForm` hosts Dashboard, Sensor Ingestion, Command Stream and Network Topology through a common sidebar | `SystemXsystem1/MainForm.cs` | Source inspection; full solution build succeeded | Complete manual navigation and interaction checklist |
| FB-07 | Asynchronous UI refresh | Overlapping timer refreshes can create duplicate concurrent requests | `PollAsync` coalesces refresh requests while a poll is active and awaits panel refreshes | `SystemXsystem1/MainForm.cs`; `ApiClient.cs` | Source inspection; full solution build succeeded | Test slow API, API outage and rapid module switching manually |
| FB-08 | Architecture health visibility | A successful build alone does not show whether API services are responding | Added/retained health snapshot with status, uptime, device counts, active errors, history count and graph size | `SystemXsystem_API/Program.cs` (`/api/health`) | Endpoint exists in source; build succeeded | Start API and capture actual HTTP response for submission evidence |

## Verification snapshot supplied from the student's Windows run

- `dotnet build .\SystemXsystem.sln` — **Build succeeded** for desktop, API and test projects.
- `dotnet run --project .\SystemXsystem_API.Tests\SystemXsystem_API.Tests.csproj` — **10/10 tests passed**.
- Latest reported workload: 50,000 inserts in 156 ms; 100-result query displayed as 0 ms at millisecond precision.

These results demonstrate compilation and the listed regression behaviours. They do not prove production load capacity, hardware link optimisation, security readiness or complete manual UI integration.

## Required final lecturer-feedback mapping

Copy the exact wording from the formative feedback PDF into this table. Do not paraphrase it as a direct quote.

| Exact lecturer feedback (paste verbatim) | Related ledger ID(s) | File/method changed | Evidence attached | Status |
|---|---|---|---|---|
| [Paste exact comment 1] | FB-01 / FB-02 | `TelemetryHistoryIndex.cs` | [Attach test output / screenshot] | [Verified / pending] |
| [Paste exact comment 2] | FB-03 / FB-04 / FB-05 | `NetworkGraphService.cs` | [Attach test output / screenshot] | [Verified / pending] |
| [Paste exact comment 3] | FB-06 / FB-07 / FB-08 | `MainForm.cs`, `Program.cs` | [Attach navigation / health evidence] | [Verified / pending] |

## Submission evidence checklist

- [ ] Attach the original formative feedback PDF or quote its exact comments in the table above.
- [ ] Attach the successful full-solution build output.
- [ ] Attach the 10/10 regression test output.
- [ ] Capture `/api/health` while the API is running.
- [ ] Capture the desktop main menu and each of the four modules.
- [ ] Capture the topology screen showing BFS, DFS and MST results.
- [ ] Capture a historical date-range query in Sensor Ingestion.
- [ ] Add the student's own accurate reflection to `CHALLENGES_AND_LEARNINGS.md`.
