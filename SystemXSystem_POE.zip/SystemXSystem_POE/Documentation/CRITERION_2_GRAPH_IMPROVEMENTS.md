# Criterion 2 — Graphs, Network Traversals and Minimum Spanning Trees

## Changes made in this iteration

| Area | Before | Improvement | Verification evidence |
|---|---|---|---|
| Graph edge model | Edge held only one illustrative weight and link type | Edge now carries energy (mJ), latency (ms), packet loss (%), signal strength (dBm), composite cost and a simulated-metrics flag | Graph builder regression test checks measured values and simulation flag |
| Routing objective | Fixed values such as 1.0 and 0.75 | Normalised composite cost: 50% energy, 30% latency and 20% packet loss | Prim regression test proves lower-cost links are selected |
| Prim implementation | Priority queue used only a double priority | Priority queue uses (cost, sequence) for deterministic tie-breaking; reports total energy, average latency and average packet loss | MST regression tests check selected edges, total cost and disconnected components |
| BFS / DFS | Traversals were implemented | Traversals retain Queue/Stack and HashSet, and avoid sorting adjacency during traversal so traversal remains O(V + E) | Regression test checks reachable nodes are visited exactly once |
| Graph validation | Some malformed graph inputs could fail indirectly | Duplicate/empty node IDs, unknown edge endpoints and invalid weights are rejected with clear argument errors | Validation is performed before graph algorithms run |
| Desktop feedback | MST status displayed a generic demo weight | UI now displays composite cost, total energy, average latency and spanning-tree/forest status | Verify visually after launching desktop app against API |

## Routing cost formula

```text
cost = 0.50 × (energy_mJ / 100)
     + 0.30 × (latency_ms / 200)
     + 0.20 × (packet_loss_percent / 100)
```

A lower value is preferred. Signal strength is retained for diagnostics; the current score uses latency and packet loss as the practical quality indicators rather than double-counting RSSI.

## Important honesty / scope note

Device link metrics are optional fields. If a device does not supply all four metrics, the graph builder fills missing values with documented demonstration defaults and sets `UsesSimulatedMetrics = true`. The project can therefore demonstrate cost-aware graph construction and Prim selection, but it must not claim physical ESP32 route optimisation until real, timestamped radio measurements are ingested.

## Tests added

The dependency-free test runner now includes tests for:

1. BFS and DFS each visiting every reachable node once.
2. Prim choosing the lower composite-cost route.
3. A disconnected graph producing a minimum spanning forest.
4. Graph construction exposing link metrics and marking simulated values.

Run from the `SystemXsystem` directory:

```powershell
dotnet run --project .\SystemXsystem_API.Tests\SystemXsystem_API.Tests.csproj
```

The full expected suite is now ten tests: six AVL/history regression tests and four graph regression tests. Execute on the target Windows machine and retain the actual console output as assessment evidence.
