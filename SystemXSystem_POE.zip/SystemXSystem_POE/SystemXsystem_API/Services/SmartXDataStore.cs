using SystemXsystem_API.Models;

namespace SystemXsystem_API.Services;

/// <summary>
/// Central in-memory store. Each advanced data structure from the brief lives here and
/// every mutation goes through a method that takes <see cref="Sync"/>, so the API
/// controllers and the background processor can share it safely.
/// </summary>
public class SmartXDataStore
{
    public readonly object Sync = new();

    // O(1) lookup of live devices by MAC address / node id.
    public Dictionary<string, Device> LiveDevices { get; } = new(StringComparer.OrdinalIgnoreCase);

    // Standard FIFO queue for normal telemetry.
    public Queue<TelemetryPacket> TelemetryQueue { get; } = new();

    // Critical alerts. Lower number = more urgent = dequeued first.
    public PriorityQueue<TelemetryPacket, int> PriorityAlertQueue { get; } = new();

    // Manual override history, powers Undo.
    public Stack<CommandLog> CommandUndoStack { get; } = new();

    // AVL-backed chronological history with a global and per-device index.
    public TelemetryHistoryIndex HistoricalLogs { get; } = new();

    // Currently active (unique) error / disconnected nodes. Prevents duplicate alerts.
    public HashSet<string> ActiveErrorNodes { get; } = new(StringComparer.OrdinalIgnoreCase);

    // Supporting collections.
    public Dictionary<string, Queue<double>> RecentReadings { get; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, PatternEntry> Patterns { get; } = new();
    public List<Notification> Notifications { get; } = new();

    public DateTime StartedAtUtc { get; } = DateTime.UtcNow;
    public int DuplicateAlertsSuppressed { get; private set; }
    public int TotalProcessed { get; private set; }

    private int _notificationId;
    private int _commandId;
    private string? _lastAlertDevice;
    private DateTime _lastAlertTime;

    // Bounded in-memory retention; oldest records are evicted when this limit is reached.
    private const int MaxHistory = 100_000;
    private const int MaxNotifications = 200;
    private const int MaxUndo = 50;
    private static readonly TimeSpan ContextWindow = TimeSpan.FromMinutes(10);

    // ---------------------------------------------------------------- devices

    public bool RegisterDevice(Device device)
    {
        lock (Sync)
        {
            if (string.IsNullOrWhiteSpace(device.Id) || LiveDevices.ContainsKey(device.Id))
                return false;

            device.LastSeen = DateTime.UtcNow;
            if (DeviceTypes.IsActuator(device.Type) && device.State == "ONLINE")
                device.State = "OFF";
            LiveDevices[device.Id] = device;
            Notify("info", $"Device registered: {device.Name} ({device.Type})");
            return true;
        }
    }

    public void SeedDemoDevices()
    {
        RegisterDevice(new Device { Id = "24:6F:28:A1:00:01", Name = "Moisture Sensor A", Type = DeviceTypes.MoistureSensor, Zone = "Hydroponic Bay", Metric = "Moisture", Unit = "%" });
        RegisterDevice(new Device { Id = "24:6F:28:A1:00:02", Name = "Moisture Sensor B", Type = DeviceTypes.MoistureSensor, Zone = "Hydroponic Bay", Metric = "Moisture", Unit = "%" });
        RegisterDevice(new Device { Id = "24:6F:28:A1:00:10", Name = "Pump A", Type = DeviceTypes.Pump, Zone = "Hydroponic Bay" });
        RegisterDevice(new Device { Id = "24:6F:28:A1:00:11", Name = "Valve 1", Type = DeviceTypes.Valve, Zone = "Hydroponic Bay" });
        RegisterDevice(new Device { Id = "24:6F:28:A1:00:12", Name = "Valve 2", Type = DeviceTypes.Valve, Zone = "Hydroponic Bay" });
        RegisterDevice(new Device { Id = "24:6F:28:B2:00:01", Name = "Power Meter 1", Type = DeviceTypes.PowerMeter, Zone = "Workshop", Metric = "Power", Unit = "W" });
        RegisterDevice(new Device { Id = "24:6F:28:B2:00:02", Name = "Smart Plug 1", Type = DeviceTypes.SmartPlug, Zone = "Workshop" });
        RegisterDevice(new Device { Id = "24:6F:28:C3:00:01", Name = "Temperature Sensor 1", Type = DeviceTypes.TemperatureSensor, Zone = "Greenhouse", Metric = "Temperature", Unit = "°C" });
    }

    public List<Device> GetDevices()
    {
        lock (Sync) return LiveDevices.Values.OrderBy(d => d.Zone).ThenBy(d => d.Name).Select(Clone).ToList();
    }

    public TopologyResponse GetTopology()
    {
        lock (Sync)
        {
            var zones = LiveDevices.Values
                .GroupBy(d => d.Zone)
                .OrderBy(g => g.Key)
                .Select(g => new TopologyZone { Zone = g.Key, Devices = g.OrderBy(d => d.Name).Select(Clone).ToList() })
                .ToList();
            return new TopologyResponse { Zones = zones };
        }
    }

    private static Device Clone(Device d) => new()
    {
        Id = d.Id, Name = d.Name, Type = d.Type, Zone = d.Zone, Metric = d.Metric,
        Unit = d.Unit, LastValue = d.LastValue, State = d.State, LastSeen = d.LastSeen
    };

    // -------------------------------------------------------------- telemetry

    /// <summary>Validates a reading and puts it on the correct queue (priority for critical).</summary>
    public (TelemetryPacket? Packet, string? Error) Ingest(TelemetryRequest request)
    {
        lock (Sync)
        {
            if (string.IsNullOrWhiteSpace(request.DeviceId) || !LiveDevices.TryGetValue(request.DeviceId, out var device))
                return (null, $"Unknown device '{request.DeviceId}'. Register it first.");
            if (DeviceTypes.IsActuator(device.Type))
                return (null, $"'{device.Name}' is an actuator and does not send telemetry.");
            if (!double.IsFinite(request.Value))
                return (null, "Telemetry value must be a finite number.");
            if (device.Type == DeviceTypes.MoistureSensor && (request.Value < 0 || request.Value > 100))
                return (null, "Moisture readings must be between 0 and 100%.");
            if (device.Type == DeviceTypes.PowerMeter && request.Value < 0)
                return (null, "Power readings cannot be negative.");

            var packet = new TelemetryPacket
            {
                DeviceId = device.Id,
                Value = request.Value,
                Timestamp = DateTime.UtcNow
            };

            var (priority, reason) = Evaluate(device, request.Value);
            if (priority.HasValue)
            {
                packet.IsCritical = true;
                packet.Reason = reason;
                PriorityAlertQueue.Enqueue(packet, priority.Value);
            }
            else
            {
                TelemetryQueue.Enqueue(packet);
            }
            return (packet, null);
        }
    }

    private static (int? Priority, string? Reason) Evaluate(Device device, double value)
    {
        switch (device.Type)
        {
            case DeviceTypes.PowerMeter when value > 2000:
                return (0, $"Severe power spike: {value:0.#} W");
            case DeviceTypes.MoistureSensor when value < 20:
                return (1, $"Drastic moisture drop: {value:0.#}%");
            case DeviceTypes.TemperatureSensor when value > 60:
                return (2, $"Overheating: {value:0.#} °C");
            default:
                return (null, null);
        }
    }

    /// <summary>Drains the priority queue first, then the FIFO queue. Returns number processed.</summary>
    public int ProcessPending()
    {
        lock (Sync)
        {
            int count = 0;
            while (PriorityAlertQueue.TryDequeue(out var urgent, out _))
            {
                ProcessPacket(urgent);
                count++;
            }
            while (TelemetryQueue.Count > 0)
            {
                ProcessPacket(TelemetryQueue.Dequeue());
                count++;
            }
            return count;
        }
    }

    private void ProcessPacket(TelemetryPacket packet)
    {
        TotalProcessed++;
        if (!LiveDevices.TryGetValue(packet.DeviceId, out var device)) return;

        device.LastValue = packet.Value;
        device.LastSeen = packet.Timestamp;
        bool wasDisconnected = device.State == "DISCONNECTED";
        device.State = "ONLINE";

        // Store the original timestamp. The AVL index uses a sequence number to
        // distinguish readings that arrive during the same clock tick.
        HistoricalLogs.Add(packet);
        if (HistoricalLogs.Count > MaxHistory)
            HistoricalLogs.RemoveOldest();

        if (!RecentReadings.TryGetValue(device.Id, out var recent))
        {
            recent = new Queue<double>();
            RecentReadings[device.Id] = recent;
        }
        recent.Enqueue(packet.Value);
        while (recent.Count > 5) recent.Dequeue();

        if (packet.IsCritical)
        {
            // HashSet.Add returns false when the node is already in error: suppress the duplicate.
            if (ActiveErrorNodes.Add(device.Id))
            {
                Notify("critical", $"{device.Name}: {packet.Reason}");
                _lastAlertDevice = device.Id;
                _lastAlertTime = DateTime.UtcNow;
            }
            else
            {
                DuplicateAlertsSuppressed++;
            }
        }
        else if (ActiveErrorNodes.Remove(device.Id))
        {
            Notify("success", wasDisconnected
                ? $"{device.Name} reconnected and is reporting normally."
                : $"{device.Name} recovered: {packet.Value:0.#}{device.Unit}");
        }
    }

    public void Disconnect(string deviceId)
    {
        lock (Sync)
        {
            if (LiveDevices.TryGetValue(deviceId, out var device)) DisconnectInternal(device);
        }
    }

    private void DisconnectInternal(Device device)
    {
        device.State = "DISCONNECTED";
        if (ActiveErrorNodes.Add(device.Id))
        {
            Notify("critical", $"{device.Name} has disconnected.");
            _lastAlertDevice = device.Id;
            _lastAlertTime = DateTime.UtcNow;
        }
        else
        {
            DuplicateAlertsSuppressed++;
        }
    }

    /// <summary>Marks sensors that have gone silent as disconnected.</summary>
    public void CheckStaleDevices(TimeSpan threshold)
    {
        lock (Sync)
        {
            var now = DateTime.UtcNow;
            foreach (var device in LiveDevices.Values)
            {
                if (DeviceTypes.IsActuator(device.Type) || device.State == "DISCONNECTED") continue;
                if (device.LastValue.HasValue && now - device.LastSeen > threshold)
                    DisconnectInternal(device);
            }
        }
    }

    public List<TelemetryPacket> GetHistory(string? deviceId, int take, DateTime? fromUtc = null, DateTime? toUtc = null)
    {
        lock (Sync)
        {
            return HistoricalLogs.Query(deviceId, take, fromUtc, toUtc);
        }
    }

    // --------------------------------------------------------------- commands

    public (CommandLog? Log, string? Error) ExecuteCommand(CommandRequest request)
    {
        lock (Sync)
        {
            var command = (request.Command ?? "").Trim().ToUpperInvariant();
            if (command != "ON" && command != "OFF")
                return (null, "Command must be ON or OFF.");

            var targets = ResolveTargets(request.Target);
            if (targets.Count == 0)
                return (null, $"No controllable devices match '{request.Target}'.");

            var log = new CommandLog { Id = ++_commandId, Target = request.Target, Command = command };
            foreach (var device in targets)
            {
                log.PreviousStates[device.Id] = device.State;
                device.State = command;
            }

            CommandUndoStack.Push(log);
            if (CommandUndoStack.Count > MaxUndo)
            {
                // Stack has no remove-bottom; rebuild keeping the newest entries.
                var keep = CommandUndoStack.Take(MaxUndo).Reverse().ToList();
                CommandUndoStack.Clear();
                foreach (var item in keep) CommandUndoStack.Push(item);
            }

            Notify("info", $"Command {command} sent to {targets.Count} device(s) [{request.Target}].");
            RecordPattern("command", request.Target, command);
            return (log, null);
        }
    }

    private List<Device> ResolveTargets(string target)
    {
        target = (target ?? "").Trim();
        IEnumerable<Device> actuators = LiveDevices.Values.Where(d => DeviceTypes.IsActuator(d.Type) && d.State != "DISCONNECTED");

        if (target == "*") return actuators.ToList();
        if (target.StartsWith("type:", StringComparison.OrdinalIgnoreCase))
        {
            var type = target.Substring(5);
            return actuators.Where(d => string.Equals(d.Type, type, StringComparison.OrdinalIgnoreCase)).ToList();
        }
        return actuators.Where(d => string.Equals(d.Id, target, StringComparison.OrdinalIgnoreCase)).ToList();
    }

    public CommandLog? Undo()
    {
        lock (Sync)
        {
            if (CommandUndoStack.Count == 0) return null;
            var log = CommandUndoStack.Pop();
            foreach (var pair in log.PreviousStates)
            {
                if (LiveDevices.TryGetValue(pair.Key, out var device) && device.State != "DISCONNECTED")
                    device.State = pair.Value;
            }
            Notify("warning", $"Undid command {log.Command} on [{log.Target}].");
            return log;
        }
    }

    public List<CommandLog> GetCommandHistory()
    {
        lock (Sync) return CommandUndoStack.ToList(); // newest first (stack order)
    }

    // ------------------------------------------------------- pattern tracking

    public List<Device> RecordSearch(string query)
    {
        lock (Sync)
        {
            query = (query ?? "").Trim();
            if (query.Length == 0) return new List<Device>();

            var matches = LiveDevices.Values
                .Where(d => d.Name.Contains(query, StringComparison.OrdinalIgnoreCase)
                         || d.Id.Contains(query, StringComparison.OrdinalIgnoreCase)
                         || d.Type.Contains(query, StringComparison.OrdinalIgnoreCase)
                         || d.Zone.Contains(query, StringComparison.OrdinalIgnoreCase))
                .Select(Clone)
                .ToList();

            RecordPattern("search", matches.Count > 0 ? matches[0].Id : query, "");
            return matches;
        }
    }

    /// <summary>Remembers that an action followed an alert on a device (caller holds the lock).</summary>
    private void RecordPattern(string kind, string target, string command)
    {
        if (_lastAlertDevice == null || DateTime.UtcNow - _lastAlertTime > ContextWindow) return;

        var key = $"{_lastAlertDevice}|{kind}|{target}|{command}";
        if (!Patterns.TryGetValue(key, out var entry))
        {
            entry = new PatternEntry { TriggerDevice = _lastAlertDevice, Kind = kind, Target = target, Command = command };
            Patterns[key] = entry;
        }
        entry.Count++;
    }

    // ---------------------------------------------------------- notifications

    private void Notify(string severity, string message)
    {
        Notifications.Add(new Notification { Id = ++_notificationId, Severity = severity, Message = message });
        if (Notifications.Count > MaxNotifications) Notifications.RemoveAt(0);
    }

    public List<Notification> GetNotifications(int sinceId)
    {
        lock (Sync) return Notifications.Where(n => n.Id > sinceId).ToList();
    }

    public DashboardSummary GetSummary()
    {
        lock (Sync)
        {
            return new DashboardSummary
            {
                TotalDevices = LiveDevices.Count,
                OnlineDevices = LiveDevices.Values.Count(d => d.State != "DISCONNECTED"),
                ActiveErrors = ActiveErrorNodes.Count,
                TelemetryQueueLength = TelemetryQueue.Count,
                PriorityQueueLength = PriorityAlertQueue.Count,
                UndoStackDepth = CommandUndoStack.Count,
                HistoryEntries = HistoricalLogs.Count,
                DuplicateAlertsSuppressed = DuplicateAlertsSuppressed,
                TotalProcessed = TotalProcessed,
                StartedAtUtc = StartedAtUtc,
                ActiveErrorNodes = ActiveErrorNodes.ToList()
            };
        }
    }
}
