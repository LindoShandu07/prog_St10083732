namespace SystemXsystem_API.Models;

public static class DeviceTypes
{
    public const string MoistureSensor = "MoistureSensor";
    public const string TemperatureSensor = "TemperatureSensor";
    public const string PowerMeter = "PowerMeter";
    public const string Valve = "Valve";
    public const string Pump = "Pump";
    public const string SmartPlug = "SmartPlug";

    public static bool IsActuator(string type) =>
        type == Valve || type == Pump || type == SmartPlug;
}

/// <summary>A registered node (ESP32, smart plug, sensor...). Stored in the O(1) live dictionary.</summary>
public class Device
{
    public string Id { get; set; } = "";          // MAC address or node id
    public string Name { get; set; } = "";
    public string Type { get; set; } = DeviceTypes.MoistureSensor;
    public string Zone { get; set; } = "Unassigned";
    public string Metric { get; set; } = "";
    public string Unit { get; set; } = "";
    public double? LastValue { get; set; }
    public string State { get; set; } = "ONLINE";  // sensors: ONLINE/DISCONNECTED, actuators: ON/OFF/DISCONNECTED
    public DateTime LastSeen { get; set; }

    // Optional link-quality measurements. Null means the application must use
    // clearly-labelled demonstration defaults until real radio metrics are available.
    public double? EnergyCostMilliJoules { get; set; }
    public double? LinkLatencyMs { get; set; }
    public double? PacketLossPercent { get; set; }
    public double? SignalStrengthDbm { get; set; }
}

public class TelemetryPacket
{
    public string DeviceId { get; set; } = "";
    public double Value { get; set; }
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public bool IsCritical { get; set; }
    public string? Reason { get; set; }
}

public class TelemetryRequest
{
    public string DeviceId { get; set; } = "";
    public double Value { get; set; }
}

public class CommandRequest
{
    /// <summary>A device id, "type:Valve" for all devices of a type, or "*" for every actuator.</summary>
    public string Target { get; set; } = "";
    /// <summary>ON or OFF.</summary>
    public string Command { get; set; } = "";
}

/// <summary>One entry on the undo stack: what changed and what each device looked like before.</summary>
public class CommandLog
{
    public int Id { get; set; }
    public string Target { get; set; } = "";
    public string Command { get; set; } = "";
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    public Dictionary<string, string> PreviousStates { get; set; } = new();
}

public class Notification
{
    public int Id { get; set; }
    public DateTime Time { get; set; } = DateTime.UtcNow;
    public string Severity { get; set; } = "info";   // info | warning | critical | success
    public string Message { get; set; } = "";
}

public class SearchRequest
{
    public string Query { get; set; } = "";
}

/// <summary>Counts how often a user action follows an alert on a given device.</summary>
public class PatternEntry
{
    public string TriggerDevice { get; set; } = "";
    public string Kind { get; set; } = "";     // "command" or "search"
    public string Target { get; set; } = "";
    public string Command { get; set; } = "";
    public int Count { get; set; }
}

public class Insight
{
    public string Title { get; set; } = "";
    public string Detail { get; set; } = "";
    public string Severity { get; set; } = "info";
    public string? DeviceId { get; set; }
    public string? SuggestedTarget { get; set; }
    public string? SuggestedCommand { get; set; }
}

public class TopologyZone
{
    public string Zone { get; set; } = "";
    public List<Device> Devices { get; set; } = new();
}

public class TopologyResponse
{
    public string Gateway { get; set; } = "Smart-X Gateway";
    public List<TopologyZone> Zones { get; set; } = new();
}

public class DashboardSummary
{
    public int TotalDevices { get; set; }
    public int OnlineDevices { get; set; }
    public int ActiveErrors { get; set; }
    public int TelemetryQueueLength { get; set; }
    public int PriorityQueueLength { get; set; }
    public int UndoStackDepth { get; set; }
    public int HistoryEntries { get; set; }
    public int DuplicateAlertsSuppressed { get; set; }
    public int TotalProcessed { get; set; }
    public DateTime StartedAtUtc { get; set; }
    public List<string> ActiveErrorNodes { get; set; } = new();
}

// Explicit tree and weighted graph models used by the topology algorithms.
public class NetworkTreeNode
{
    public string Id { get; set; } = "";
    public string Label { get; set; } = "";
    public string Kind { get; set; } = "";
    public string? State { get; set; }
    public List<NetworkTreeNode> Children { get; set; } = new();
}
public class NetworkNode
{
    public string Id { get; set; } = "";
    public string Label { get; set; } = "";
    public string Kind { get; set; } = "";
    public string? State { get; set; }
}
public class NetworkEdge
{
    public string Source { get; set; } = "";
    public string Target { get; set; } = "";

    /// <summary>Composite routing cost. Lower values are preferred by Prim's algorithm.</summary>
    public double Weight { get; set; }
    public string LinkType { get; set; } = "";
    public double EnergyCostMilliJoules { get; set; }
    public double LatencyMs { get; set; }
    public double PacketLossPercent { get; set; }
    public double SignalStrengthDbm { get; set; }
    public bool UsesSimulatedMetrics { get; set; }
}
public class NetworkGraph
{
    public List<NetworkNode> Nodes { get; set; } = new();
    public List<NetworkEdge> Edges { get; set; } = new();
}
public class NetworkTraversalResult
{
    public string Method { get; set; } = "";
    public string StartNode { get; set; } = "";
    public List<string> VisitedNodeIds { get; set; } = new();
    public int VisitedCount { get; set; }
}
public class MinimumSpanningTreeResult
{
    public List<NetworkEdge> Edges { get; set; } = new();
    public double TotalWeight { get; set; }
    public double TotalEnergyCostMilliJoules { get; set; }
    public double AverageLatencyMs { get; set; }
    public double AveragePacketLossPercent { get; set; }
    public int ComponentCount { get; set; }
    public bool IsSpanningTree { get; set; }
}
