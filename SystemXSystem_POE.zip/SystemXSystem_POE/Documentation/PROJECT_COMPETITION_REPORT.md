# Smart-X Project Competition Report

**Project:** Smart-X Network Monitoring and Management System  
**Student:** Lindokuhle Mbatha  
**Course:** PROG7312

## 1. Project concept

Smart-X is a desktop-based IoT network monitoring and management demonstrator. It combines a Windows Forms operator interface with an ASP.NET Core API to register devices, receive sensor telemetry, prioritise critical readings, control actuators and inspect network topology.

## 2. Problem addressed

IoT environments can contain many sensors and actuators. Operators need a clear way to identify devices, distinguish routine readings from urgent alerts, review historical behaviour and issue corrective commands. Smart-X demonstrates these workflows in one application.

## 3. Main differentiators

- Combines a live-style dashboard, sensor ingestion, command control and network topology in one desktop client.
- Demonstrates multiple data structures with practical purposes rather than isolated examples.
- Gives critical telemetry a priority queue separate from normal FIFO traffic.
- Uses a stack to support undo of actuator commands.
- Tracks unique active error nodes to suppress repeated alerts.
- Adds an explicit network tree, BFS/DFS traversals and Prim's MST for algorithm demonstration.
- Offers date-range filtering of historical telemetry.
- Includes a rule/pattern-based Insight Engine to surface trends and operational suggestions.

## 4. Demonstration story

1. Open the dashboard and show the connected API and seeded devices.
2. Submit a normal sensor reading and show it in the timeline.
3. Submit a critical reading and explain priority queue handling and alert creation.
4. Use the date pickers to query a historical time interval.
5. Open Network Topology and explain the gateway, zones and device tree.
6. Run BFS and DFS from the gateway and compare their visit order.
7. Calculate the MST and explain the selected minimum-cost links.
8. Open Command Stream, switch an actuator ON, then use Undo.
9. Return to the dashboard and show the active notifications and suggestions.

## 5. Competition value

The project's value is educational and demonstrative: it presents network monitoring concepts, collection choices and graph algorithms in an interface that can be explored by an operator. The current graph link costs are simulated. The project should not be presented as a field-tested wireless mesh optimiser until measured ESP32 link metrics are integrated.

## 6. Future development

Potential competition extensions include persistent telemetry storage, live ESP32 integration, measured RSSI/latency-based edge weights, shortest-path routing, security hardening, automated tests, containerised API deployment and a web-based multi-user dashboard.

## 7. Evidence to include

Capture screenshots of the dashboard, normal and critical telemetry, date-range query, topology tree, BFS result, DFS result, MST result, command execution and undo. Include a short video showing the complete workflow. Include the repository URL and ensure the repository contains source files and a meaningful commit history.
