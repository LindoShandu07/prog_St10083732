using SystemXsystem_API.Services;

var builder = WebApplication.CreateBuilder(args);

// Fixed address so the client's default URL always works.
builder.WebHost.UseUrls("http://localhost:5000");

// Empty strings (e.g. no metric for a valve) must not be rejected by implicit [Required] checks.
builder.Services.AddControllers(options =>
{
    options.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true;
});
builder.Services.AddSingleton<SmartXDataStore>();
builder.Services.AddSingleton<InsightEngine>();
builder.Services.AddSingleton<NetworkGraphService>();
builder.Services.AddHostedService<TelemetryProcessor>();

var app = builder.Build();

app.MapControllers();
app.MapGet("/", () => Results.Ok(new { name = "Smart-X Gateway API", status = "running", health = "/api/health" }));
app.MapGet("/api/health", (SmartXDataStore store, NetworkGraphService graphService) =>
{
    var summary = store.GetSummary();
    var graph = graphService.BuildGraph(store.GetTopology());
    return Results.Ok(new
    {
        success = true,
        status = "healthy",
        message = "Smart-X API is running.",
        startedAtUtc = store.StartedAtUtc,
        uptimeSeconds = (int)(DateTime.UtcNow - store.StartedAtUtc).TotalSeconds,
        registeredDevices = summary.TotalDevices,
        onlineDevices = summary.OnlineDevices,
        activeErrors = summary.ActiveErrors,
        telemetryHistoryEntries = summary.HistoryEntries,
        graphNodes = graph.Nodes.Count,
        graphEdges = graph.Edges.Count
    });
});

// Load a small, repeatable demo network on startup so the application is ready
// to demonstrate immediately. The seed endpoint remains available in the UI.
var dataStore = app.Services.GetRequiredService<SmartXDataStore>();
dataStore.SeedDemoDevices();

app.Run();
