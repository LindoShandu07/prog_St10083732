using System.Text;
using System.Text.Json;

namespace SystemXsystem1;

// ---------------------------------------------------------------- DTOs

public class DeviceDto
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string Type { get; set; } = "";
    public string Zone { get; set; } = "";
    public string Metric { get; set; } = "";
    public string Unit { get; set; } = "";
    public double? LastValue { get; set; }
    public string State { get; set; } = "";
    public DateTime LastSeen { get; set; }

    public bool IsActuator => Type == "Valve" || Type == "Pump" || Type == "SmartPlug";
    public override string ToString() => $"{Name}  ({Id})";
}

public class PacketDto
{
    public string DeviceId { get; set; } = "";
    public double Value { get; set; }
    public DateTime Timestamp { get; set; }
    public bool IsCritical { get; set; }
    public string? Reason { get; set; }
}

public class NotificationDto
{
    public int Id { get; set; }
    public DateTime Time { get; set; }
    public string Severity { get; set; } = "info";
    public string Message { get; set; } = "";
}

public class InsightDto
{
    public string Title { get; set; } = "";
    public string Detail { get; set; } = "";
    public string Severity { get; set; } = "info";
    public string? DeviceId { get; set; }
    public string? SuggestedTarget { get; set; }
    public string? SuggestedCommand { get; set; }
    public bool CanApply => !string.IsNullOrEmpty(SuggestedTarget) && !string.IsNullOrEmpty(SuggestedCommand);
}

public class SummaryDto
{
    public int TotalDevices { get; set; }
    public int OnlineDevices { get; set; }
    public int ActiveErrors { get; set; }
    public int TelemetryQueueLength { get; set; }
    public int PriorityQueueLength { get; set; }
    public int UndoStackDepth { get; set; }
    public int HistoryEntries { get; set; }
    public int DuplicateAlertsSuppressed { get; set; }
    public int TotalProcessed { get; set; }
    public DateTime StartedAtUtc { get; set; }
    public List<string> ActiveErrorNodes { get; set; } = new();
}

public class CommandLogDto
{
    public int Id { get; set; }
    public string Target { get; set; } = "";
    public string Command { get; set; } = "";
    public DateTime Timestamp { get; set; }
    public Dictionary<string, string> PreviousStates { get; set; } = new();
}

public class ZoneDto
{
    public string Zone { get; set; } = "";
    public List<DeviceDto> Devices { get; set; } = new();
}

public class TopologyDto
{
    public string Gateway { get; set; } = "Smart-X Gateway";
    public List<ZoneDto> Zones { get; set; } = new();
}

public class ApiException : Exception
{
    public ApiException(string message) : base(message) { }
}

// ---------------------------------------------------------- HTTP client

public class ApiClient
{
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(5) };
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    public string BaseUrl { get; set; } = "http://localhost:5000";

    private string Url(string path) => BaseUrl.Trim().TrimEnd('/') + path;

    public async Task<T> GetAsync<T>(string path)
    {
        string body = await SendAsync(HttpMethod.Get, path, null);
        return JsonSerializer.Deserialize<T>(body, Json) ?? throw new ApiException("The API returned an empty response.");
    }

    public async Task<T> PostAsync<T>(string path, object? payload = null)
    {
        string body = await SendAsync(HttpMethod.Post, path, payload);
        return JsonSerializer.Deserialize<T>(body, Json) ?? throw new ApiException("The API returned an empty response.");
    }

    public async Task PostAsync(string path, object? payload = null)
    {
        await SendAsync(HttpMethod.Post, path, payload);
    }

    private async Task<string> SendAsync(HttpMethod method, string path, object? payload)
    {
        using var request = new HttpRequestMessage(method, Url(path));
        if (payload != null)
            request.Content = new StringContent(JsonSerializer.Serialize(payload, Json), Encoding.UTF8, "application/json");

        HttpResponseMessage response;
        try
        {
            response = await _http.SendAsync(request);
        }
        catch (Exception ex) when (ex is HttpRequestException || ex is TaskCanceledException || ex is InvalidOperationException || ex is UriFormatException)
        {
            throw new ApiException($"Cannot reach the API at {BaseUrl}. Is it running?");
        }

        using (response)
        {
            string body = await response.Content.ReadAsStringAsync();
            if (!response.IsSuccessStatusCode)
                throw new ApiException(ExtractError(body, (int)response.StatusCode));
            return body;
        }
    }

    private static string ExtractError(string body, int status)
    {
        try
        {
            using var doc = JsonDocument.Parse(body);
            foreach (var name in new[] { "error", "title" })
            {
                if (doc.RootElement.ValueKind == JsonValueKind.Object &&
                    doc.RootElement.TryGetProperty(name, out var value) &&
                    value.ValueKind == JsonValueKind.String)
                    return value.GetString() ?? $"HTTP {status}";
            }
        }
        catch (JsonException) { }
        return $"The API returned HTTP {status}.";
    }
}


public class TraversalDto
{
    public string Method { get; set; } = "";
    public string StartNode { get; set; } = "";
    public List<string> VisitedNodeIds { get; set; } = new();
    public int VisitedCount { get; set; }
}
public class MstDto
{
    public List<NetworkEdgeDto> Edges { get; set; } = new();
    public double TotalWeight { get; set; }
    public double TotalEnergyCostMilliJoules { get; set; }
    public double AverageLatencyMs { get; set; }
    public double AveragePacketLossPercent { get; set; }
    public int ComponentCount { get; set; }
    public bool IsSpanningTree { get; set; }
}
public class NetworkEdgeDto
{
    public string Source { get; set; } = "";
    public string Target { get; set; } = "";
    public double Weight { get; set; }
    public string LinkType { get; set; } = "";
    public double EnergyCostMilliJoules { get; set; }
    public double LatencyMs { get; set; }
    public double PacketLossPercent { get; set; }
    public double SignalStrengthDbm { get; set; }
    public bool UsesSimulatedMetrics { get; set; }
}
