@echo off
setlocal
set "ROOT=%~dp0"
cd /d "%ROOT%"
echo Checking .NET SDK...
dotnet --version
if errorlevel 1 (
  echo .NET SDK was not found. Install the .NET 10 SDK and reopen this window.
  pause
  exit /b 1
)
echo Restoring solution packages (this creates project.assets.json)...
dotnet restore "%ROOT%SystemXsystem.sln"
if errorlevel 1 (
  echo Package restore failed. Check the SDK and network connection.
  pause
  exit /b 1
)
echo Starting Smart-X API...
start "Smart-X API" cmd /k "cd /d ""%ROOT%SystemXsystem_API"" && dotnet run --no-restore"
echo Waiting for API health endpoint...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ready=$false; for($i=0;$i -lt 30;$i++){ try { $r=Invoke-RestMethod 'http://localhost:5000/api/health' -TimeoutSec 2; if($r.success){$ready=$true;break} } catch {}; Start-Sleep -Seconds 1 }; if(-not $ready){ Write-Host 'API did not become healthy within 30 seconds.'; exit 1 }"
if errorlevel 1 (
  echo API did not start. Check the Smart-X API terminal for errors.
  pause
  exit /b 1
)
echo Starting Smart-X Windows Forms client...
dotnet run --no-restore --project "%ROOT%SystemXsystem1\SystemXsystem1.csproj"
if errorlevel 1 (
  echo.
  echo The client did not start. Check .NET 10 SDK and Windows Desktop Runtime.
  pause
)
endlocal
