using System.Drawing.Drawing2D;

namespace SystemXsystem1;

/// <summary>One consistent look (colours, fonts, spacing) shared by every screen.</summary>
public static class Theme
{
    public static readonly Color Sidebar = Color.FromArgb(15, 23, 42);
    public static readonly Color SidebarActive = Color.FromArgb(30, 41, 59);
    public static readonly Color Accent = Color.FromArgb(13, 148, 136);
    public static readonly Color Bg = Color.FromArgb(241, 245, 249);
    public static readonly Color Card = Color.White;
    public static readonly Color Text = Color.FromArgb(15, 23, 42);
    public static readonly Color Muted = Color.FromArgb(100, 116, 139);
    public static readonly Color Line = Color.FromArgb(226, 232, 240);
    public static readonly Color Critical = Color.FromArgb(220, 38, 38);
    public static readonly Color Warning = Color.FromArgb(217, 119, 6);
    public static readonly Color Success = Color.FromArgb(22, 163, 74);
    public static readonly Color Info = Color.FromArgb(37, 99, 235);

    public static readonly Font Body = new("Segoe UI", 10f);
    public static readonly Font Small = new("Segoe UI", 8.5f);
    public static readonly Font Bold = new("Segoe UI Semibold", 10f);
    public static readonly Font Heading = new("Segoe UI Semibold", 12f);
    public static readonly Font Title = new("Segoe UI Semibold", 16f);
    public static readonly Font Big = new("Segoe UI Semibold", 22f);

    public static Color SeverityColor(string severity) => severity switch
    {
        "critical" => Critical,
        "warning" => Warning,
        "success" => Success,
        _ => Info
    };

    public static Button MakeButton(string text, bool primary = true, int width = 130)
    {
        var button = new Button
        {
            Text = text,
            Width = width,
            Height = 34,
            FlatStyle = FlatStyle.Flat,
            Font = Bold,
            Cursor = Cursors.Hand,
            BackColor = primary ? Accent : Color.White,
            ForeColor = primary ? Color.White : Text,
            UseVisualStyleBackColor = false
        };
        button.FlatAppearance.BorderColor = primary ? Accent : Line;
        button.FlatAppearance.BorderSize = 1;
        return button;
    }

    public static Label MakeLabel(string text, Font? font = null, Color? color = null) => new()
    {
        Text = text,
        Font = font ?? Body,
        ForeColor = color ?? Text,
        AutoSize = true
    };

    /// <summary>White card with a heading, body content goes in the returned panel's remaining space.</summary>
    public static Panel MakeCard(string heading)
    {
        var card = new Panel { BackColor = Card, Dock = DockStyle.Fill, Padding = new Padding(16), Margin = new Padding(6) };
        var title = new Label
        {
            Text = heading,
            Font = Heading,
            ForeColor = Text,
            Dock = DockStyle.Top,
            Height = 32,
            TextAlign = ContentAlignment.MiddleLeft
        };
        card.Controls.Add(title);
        return card;
    }

    public static GraphicsPath Rounded(Rectangle r, int radius)
    {
        int d = radius * 2;
        var path = new GraphicsPath();
        path.AddArc(r.X, r.Y, d, d, 180, 90);
        path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }

    public static string DeviceStateText(DeviceDto d)
    {
        if (d.State == "DISCONNECTED") return "DISCONNECTED";
        if (d.IsActuator) return d.State;
        return d.LastValue.HasValue ? $"{d.LastValue.Value:0.#} {d.Unit}" : "no data yet";
    }
}

/// <summary>Base class for every screen so the main window can refresh whichever one is showing.</summary>
public abstract class ModulePanel : UserControl
{
    protected readonly ApiClient Api;

    protected ModulePanel(ApiClient api)
    {
        Api = api;
        Dock = DockStyle.Fill;
        BackColor = Theme.Bg;
        Font = Theme.Body;
        Padding = new Padding(16);
        DoubleBuffered = true;
    }

    public abstract Task RefreshAsync();

    protected static void SetStatus(Label label, string message, string severity)
    {
        label.Text = message;
        label.ForeColor = Theme.SeverityColor(severity);
    }
}
