using System.Drawing.Drawing2D;

namespace SystemXsystem1;

/// <summary>Network Topology: gateway -> zones -> devices, coloured by live status.</summary>
public class TopologyPanel : ModulePanel
{
    private readonly TopologyCanvas _canvas = new();

    private readonly Label _algorithmStatus = new() { AutoSize = true, Padding = new Padding(8, 7, 8, 0) };

    public TopologyPanel(ApiClient api) : base(api)
    {
        var card = Theme.MakeCard("Network topology and graph algorithms");
        var toolbar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 42, WrapContents = false, BackColor = Theme.Card };
        var bfs = Theme.MakeButton("Run BFS", false, 90);
        var dfs = Theme.MakeButton("Run DFS", false, 90);
        var mst = Theme.MakeButton("Calculate MST", true, 125);
        bfs.Click += async (_, _) => await RunTraversalAsync("BFS");
        dfs.Click += async (_, _) => await RunTraversalAsync("DFS");
        mst.Click += async (_, _) => await RunMstAsync();
        toolbar.Controls.AddRange(new Control[] { bfs, dfs, mst, _algorithmStatus });
        _canvas.Dock = DockStyle.Fill;
        card.Controls.Add(_canvas);
        card.Controls.Add(toolbar);
        card.Controls.SetChildIndex(_canvas, 0);
        card.Controls.SetChildIndex(toolbar, 1);
        Controls.Add(card);
    }

    private async Task RunTraversalAsync(string method)
    {
        try
        {
            var result = await Api.GetAsync<TraversalDto>($"/api/topology/algorithms/traverse?startNode=gateway&method={method}");
            _algorithmStatus.ForeColor = Theme.Success;
            _algorithmStatus.Text = $"{result.Method}: visited {result.VisitedCount} nodes — {string.Join(" → ", result.VisitedNodeIds.Take(5))}{(result.VisitedCount > 5 ? " …" : "")}";
        }
        catch (Exception ex) { _algorithmStatus.ForeColor = Theme.Critical; _algorithmStatus.Text = ex.Message; }
    }

    private async Task RunMstAsync()
    {
        try
        {
            var result = await Api.GetAsync<MstDto>("/api/topology/algorithms/mst");
            _algorithmStatus.ForeColor = Theme.Success;
            string structure = result.IsSpanningTree ? "spanning tree" : $"forest ({result.ComponentCount} components)";
            _algorithmStatus.Text = $"Prim: {result.Edges.Count} links | cost {result.TotalWeight:0.000} | energy {result.TotalEnergyCostMilliJoules:0.#} mJ | latency {result.AverageLatencyMs:0.#} ms avg | {structure}";
        }
        catch (Exception ex) { _algorithmStatus.ForeColor = Theme.Critical; _algorithmStatus.Text = ex.Message; }
    }

    public override async Task RefreshAsync()
    {
        var topology = await Api.GetAsync<TopologyDto>("/api/topology");
        var summary = await Api.GetAsync<SummaryDto>("/api/dashboard");
        _canvas.SetData(topology, new HashSet<string>(summary.ActiveErrorNodes));
    }
}

public class TopologyCanvas : Panel
{
    private TopologyDto? _topology;
    private HashSet<string> _alerts = new();

    private const int ColumnWidth = 240;
    private const int BoxWidth = 200;
    private const int DeviceHeight = 50;
    private const int DeviceGap = 14;
    private const int DevicesTop = 210;

    public TopologyCanvas()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
        AutoScroll = true;
        BackColor = Theme.Card;
    }

    public void SetData(TopologyDto topology, HashSet<string> alerts)
    {
        _topology = topology;
        _alerts = alerts;
        UpdateScrollSize();
        Invalidate();
    }

    protected override void OnResize(EventArgs eventargs)
    {
        base.OnResize(eventargs);
        UpdateScrollSize();
    }

    private int ContentWidth => Math.Max(ClientSize.Width, (_topology?.Zones.Count ?? 0) * ColumnWidth + 60);

    private void UpdateScrollSize()
    {
        int maxDevices = _topology == null || _topology.Zones.Count == 0 ? 0 : _topology.Zones.Max(z => z.Devices.Count);
        AutoScrollMinSize = new Size((_topology?.Zones.Count ?? 0) * ColumnWidth + 60, DevicesTop + maxDevices * (DeviceHeight + DeviceGap) + 30);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;

        DrawLegend(g);

        if (_topology == null || _topology.Zones.Count == 0)
        {
            TextRenderer.DrawText(g, "No devices yet. Load demo devices from the Dashboard or register a node.", Theme.Body,
                new Point(20, 60), Theme.Muted);
            return;
        }

        g.TranslateTransform(AutoScrollPosition.X, AutoScrollPosition.Y);

        int width = ContentWidth;
        int zones = _topology.Zones.Count;
        int left = (width - zones * ColumnWidth) / 2;

        var gateway = new Rectangle(width / 2 - 110, 40, 220, 56);
        using var linePen = new Pen(Color.FromArgb(148, 163, 184), 2f);
        using var textBrush = new SolidBrush(Theme.Text);
        using var whiteBrush = new SolidBrush(Color.White);
        var center = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter };

        for (int z = 0; z < zones; z++)
        {
            var zone = _topology.Zones[z];
            int cx = left + z * ColumnWidth + ColumnWidth / 2;
            var zoneBox = new Rectangle(cx - BoxWidth / 2, 130, BoxWidth, 44);

            g.DrawLine(linePen, width / 2, gateway.Bottom, cx, zoneBox.Top);
            if (zone.Devices.Count > 0)
            {
                int lastY = DevicesTop + (zone.Devices.Count - 1) * (DeviceHeight + DeviceGap) + DeviceHeight / 2;
                g.DrawLine(linePen, cx, zoneBox.Bottom, cx, lastY);
            }
        }

        // Boxes are drawn after the lines so the lines tuck behind them.
        using (var path = Theme.Rounded(gateway, 10))
        using (var fill = new SolidBrush(Theme.Sidebar))
        {
            g.FillPath(fill, path);
            g.DrawString(_topology.Gateway, Theme.Bold, whiteBrush, gateway, center);
        }

        for (int z = 0; z < zones; z++)
        {
            var zone = _topology.Zones[z];
            int cx = left + z * ColumnWidth + ColumnWidth / 2;
            var zoneBox = new Rectangle(cx - BoxWidth / 2, 130, BoxWidth, 44);

            using (var path = Theme.Rounded(zoneBox, 10))
            using (var fill = new SolidBrush(Theme.Accent))
            {
                g.FillPath(fill, path);
                g.DrawString($"{zone.Zone}  ({zone.Devices.Count})", Theme.Bold, whiteBrush, zoneBox, center);
            }

            for (int i = 0; i < zone.Devices.Count; i++)
            {
                var d = zone.Devices[i];
                var box = new Rectangle(cx - BoxWidth / 2, DevicesTop + i * (DeviceHeight + DeviceGap), BoxWidth, DeviceHeight);
                bool alert = d.State == "DISCONNECTED" || _alerts.Contains(d.Id);
                var (fillColor, borderColor) = StatusColors(d, alert);

                using var boxPath = Theme.Rounded(box, 8);
                using var fillBrush = new SolidBrush(fillColor);
                using var borderPen = new Pen(borderColor, alert ? 2.5f : 1.5f);
                g.FillPath(fillBrush, boxPath);
                g.DrawPath(borderPen, boxPath);

                var nameRect = new RectangleF(box.X + 8, box.Y + 6, box.Width - 16, 20);
                var infoRect = new RectangleF(box.X + 8, box.Y + 27, box.Width - 16, 18);
                var left_ = new StringFormat { Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap };
                g.DrawString(d.Name, Theme.Bold, textBrush, nameRect, left_);
                using var mutedBrush = new SolidBrush(alert ? Theme.Critical : Theme.Muted);
                g.DrawString(Theme.DeviceStateText(d), Theme.Small, mutedBrush, infoRect, left_);
            }
        }
    }

    private static (Color Fill, Color Border) StatusColors(DeviceDto d, bool alert)
    {
        if (alert) return (Color.FromArgb(254, 226, 226), Theme.Critical);
        if (d.IsActuator)
            return d.State == "ON"
                ? (Color.FromArgb(220, 252, 231), Theme.Success)
                : (Color.FromArgb(241, 245, 249), Color.FromArgb(148, 163, 184));
        return (Color.FromArgb(204, 251, 241), Theme.Accent);
    }

    private static void DrawLegend(Graphics g)
    {
        var items = new (string Text, Color Color)[]
        {
            ("Sensor online", Theme.Accent),
            ("Actuator ON", Theme.Success),
            ("Actuator OFF", Color.FromArgb(148, 163, 184)),
            ("Alert / disconnected", Theme.Critical)
        };
        int x = 10;
        foreach (var (text, color) in items)
        {
            using var brush = new SolidBrush(color);
            g.FillEllipse(brush, x, 12, 12, 12);
            TextRenderer.DrawText(g, text, Theme.Small, new Point(x + 16, 9), Theme.Muted);
            x += 30 + TextRenderer.MeasureText(text, Theme.Small).Width;
        }
    }
}
