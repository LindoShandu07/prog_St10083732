using SystemXsystem_API.Models;

namespace SystemXsystem_API.Services;

/// <summary>
/// Builds the topology graph and runs BFS, DFS and Prim's minimum spanning forest.
/// Routing weights combine energy, latency and packet-loss costs; lower is better.
/// </summary>
public sealed class NetworkGraphService
{
    // Normalisation limits make unlike units comparable before applying the weights.
    private const double EnergyReferenceMilliJoules = 100.0;
    private const double LatencyReferenceMs = 200.0;
    private const double EnergyWeight = 0.50;
    private const double LatencyWeight = 0.30;
    private const double PacketLossWeight = 0.20;

    public NetworkTreeNode BuildTree(TopologyResponse topology)
    {
        var root = new NetworkTreeNode { Id = "gateway", Label = topology.Gateway, Kind = "gateway" };
        foreach (var zone in topology.Zones)
        {
            var zoneNode = new NetworkTreeNode { Id = "zone:" + zone.Zone, Label = zone.Zone, Kind = "zone" };
            foreach (var device in zone.Devices.OrderBy(d => d.Name))
                zoneNode.Children.Add(new NetworkTreeNode { Id = device.Id, Label = device.Name, Kind = "device", State = device.State });
            root.Children.Add(zoneNode);
        }
        return root;
    }

    public NetworkGraph BuildGraph(TopologyResponse topology)
    {
        ArgumentNullException.ThrowIfNull(topology);
        var graph = new NetworkGraph();
        graph.Nodes.Add(new NetworkNode { Id = "gateway", Label = topology.Gateway, Kind = "gateway" });

        foreach (var zone in topology.Zones)
        {
            string zoneId = "zone:" + zone.Zone;
            graph.Nodes.Add(new NetworkNode { Id = zoneId, Label = zone.Zone, Kind = "zone" });
            graph.Edges.Add(CreateEdge("gateway", zoneId, "gateway-zone", 35, 25, 1.5, -55, true));

            var devices = zone.Devices.OrderBy(d => d.Id, StringComparer.OrdinalIgnoreCase).ToList();
            foreach (var device in devices)
            {
                graph.Nodes.Add(new NetworkNode { Id = device.Id, Label = device.Name, Kind = "device", State = device.State });
                var metrics = MetricsFor(device);
                graph.Edges.Add(CreateEdge(zoneId, device.Id, "zone-device", metrics.Energy, metrics.Latency,
                    metrics.PacketLoss, metrics.Signal, metrics.Simulated));
            }

            // Same-zone peer links model optional mesh paths. Average endpoint metrics
            // so both devices influence the estimated cost of using that link.
            for (int i = 0; i < devices.Count; i++)
            {
                for (int j = i + 1; j < devices.Count; j++)
                {
                    var a = MetricsFor(devices[i]);
                    var b = MetricsFor(devices[j]);
                    graph.Edges.Add(CreateEdge(devices[i].Id, devices[j].Id, "same-zone-peer",
                        (a.Energy + b.Energy) / 2.0,
                        (a.Latency + b.Latency) / 2.0,
                        (a.PacketLoss + b.PacketLoss) / 2.0,
                        (a.Signal + b.Signal) / 2.0,
                        a.Simulated || b.Simulated));
                }
            }
        }
        return graph;
    }

    /// <summary>Breadth-first or depth-first traversal; O(V + E).</summary>
    public NetworkTraversalResult Traverse(NetworkGraph graph, string startId, string method)
    {
        ValidateGraph(graph);
        var adjacency = BuildAdjacency(graph);
        if (!adjacency.ContainsKey(startId)) throw new ArgumentException($"Unknown start node '{startId}'.");
        var visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var order = new List<string>();
        if (method.Equals("BFS", StringComparison.OrdinalIgnoreCase))
        {
            var queue = new Queue<string>();
            queue.Enqueue(startId);
            visited.Add(startId);
            while (queue.Count > 0)
            {
                var current = queue.Dequeue();
                order.Add(current);
                foreach (var next in adjacency[current])
                    if (visited.Add(next)) queue.Enqueue(next);
            }
        }
        else if (method.Equals("DFS", StringComparison.OrdinalIgnoreCase))
        {
            var stack = new Stack<string>();
            stack.Push(startId);
            while (stack.Count > 0)
            {
                var current = stack.Pop();
                if (!visited.Add(current)) continue;
                order.Add(current);
                foreach (var next in adjacency[current])
                    if (!visited.Contains(next)) stack.Push(next);
            }
        }
        else throw new ArgumentException("Traversal method must be BFS or DFS.");

        return new NetworkTraversalResult { Method = method.ToUpperInvariant(), StartNode = startId,
            VisitedNodeIds = order, VisitedCount = order.Count };
    }

    /// <summary>
    /// Prim's algorithm. O((V + E) log E) with the priority queue.
    /// A minimum spanning forest is returned when the graph is disconnected.
    /// </summary>
    public MinimumSpanningTreeResult MinimumSpanningTree(NetworkGraph graph)
    {
        ValidateGraph(graph);
        var adjacency = BuildWeightedAdjacency(graph);
        var visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var result = new MinimumSpanningTreeResult();
        long sequence = 0; // deterministic tie-break when two links have equal cost

        foreach (var start in graph.Nodes.Select(n => n.Id).OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
        {
            if (!visited.Add(start)) continue;
            var candidates = new PriorityQueue<NetworkEdge, (double Weight, long Sequence)>();
            AddFrontier(start);

            while (candidates.TryDequeue(out var edge, out _))
            {
                string next = visited.Contains(edge.Source) ? edge.Target : edge.Source;
                if (visited.Contains(next)) continue;
                visited.Add(next);
                result.Edges.Add(edge);
                result.TotalWeight += edge.Weight;
                result.TotalEnergyCostMilliJoules += edge.EnergyCostMilliJoules;
                AddFrontier(next);
            }

            void AddFrontier(string node)
            {
                if (!adjacency.TryGetValue(node, out var edges)) return;
                foreach (var edge in edges)
                {
                    if (visited.Contains(edge.Source) && visited.Contains(edge.Target)) continue;
                    candidates.Enqueue(edge, (edge.Weight, sequence++));
                }
            }
        }

        result.ComponentCount = CountComponents(graph);
        result.IsSpanningTree = graph.Nodes.Count == 0 ||
            (result.ComponentCount == 1 && result.Edges.Count == graph.Nodes.Count - 1);
        if (result.Edges.Count > 0)
        {
            result.AverageLatencyMs = result.Edges.Average(e => e.LatencyMs);
            result.AveragePacketLossPercent = result.Edges.Average(e => e.PacketLossPercent);
        }
        return result;
    }

    private static NetworkEdge CreateEdge(string source, string target, string type,
        double energy, double latency, double packetLoss, double signal, bool simulated)
    {
        energy = Clamp(energy, 0, EnergyReferenceMilliJoules * 10);
        latency = Clamp(latency, 0, LatencyReferenceMs * 10);
        packetLoss = Clamp(packetLoss, 0, 100);
        signal = Clamp(signal, -120, 0);

        // Weighted, dimensionless score: 50% energy, 30% latency, 20% packet loss.
        // Signal is retained as diagnostic metadata; packet loss and latency reflect
        // its practical impact without double-counting it in the score.
        double score = EnergyWeight * (energy / EnergyReferenceMilliJoules) +
                       LatencyWeight * (latency / LatencyReferenceMs) +
                       PacketLossWeight * (packetLoss / 100.0);
        return new NetworkEdge
        {
            Source = source, Target = target, LinkType = type,
            EnergyCostMilliJoules = energy, LatencyMs = latency,
            PacketLossPercent = packetLoss, SignalStrengthDbm = signal,
            Weight = Math.Round(score, 6), UsesSimulatedMetrics = simulated
        };
    }

    private static (double Energy, double Latency, double PacketLoss, double Signal, bool Simulated) MetricsFor(Device device)
    {
        bool simulated = !device.EnergyCostMilliJoules.HasValue || !device.LinkLatencyMs.HasValue ||
                         !device.PacketLossPercent.HasValue || !device.SignalStrengthDbm.HasValue;
        return (
            device.EnergyCostMilliJoules ?? 25.0,
            device.LinkLatencyMs ?? (string.Equals(device.State, "DISCONNECTED", StringComparison.OrdinalIgnoreCase) ? 180.0 : 20.0),
            device.PacketLossPercent ?? (string.Equals(device.State, "DISCONNECTED", StringComparison.OrdinalIgnoreCase) ? 15.0 : 1.0),
            device.SignalStrengthDbm ?? -62.0,
            simulated);
    }

    private static double Clamp(double value, double min, double max) =>
        double.IsFinite(value) ? Math.Clamp(value, min, max) : min;

    private static void ValidateGraph(NetworkGraph graph)
    {
        ArgumentNullException.ThrowIfNull(graph);
        var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var node in graph.Nodes)
        {
            if (string.IsNullOrWhiteSpace(node.Id)) throw new ArgumentException("Graph node IDs cannot be empty.");
            if (!ids.Add(node.Id)) throw new ArgumentException($"Duplicate graph node ID '{node.Id}'.");
        }
        foreach (var edge in graph.Edges)
        {
            if (string.IsNullOrWhiteSpace(edge.Source) || string.IsNullOrWhiteSpace(edge.Target))
                throw new ArgumentException("Graph edges must have source and target IDs.");
            if (!ids.Contains(edge.Source) || !ids.Contains(edge.Target))
                throw new ArgumentException($"Graph edge '{edge.Source}' → '{edge.Target}' references an unknown node.");
            if (!double.IsFinite(edge.Weight) || edge.Weight < 0)
                throw new ArgumentException("Graph edge weights must be finite and non-negative.");
        }
    }

    private static Dictionary<string, List<string>> BuildAdjacency(NetworkGraph graph)
    {
        var map = graph.Nodes.ToDictionary(n => n.Id, _ => new List<string>(), StringComparer.OrdinalIgnoreCase);
        foreach (var edge in graph.Edges)
            if (map.ContainsKey(edge.Source) && map.ContainsKey(edge.Target) && !string.Equals(edge.Source, edge.Target, StringComparison.OrdinalIgnoreCase))
            { map[edge.Source].Add(edge.Target); map[edge.Target].Add(edge.Source); }
        return map;
    }

    private static Dictionary<string, List<NetworkEdge>> BuildWeightedAdjacency(NetworkGraph graph)
    {
        var map = graph.Nodes.ToDictionary(n => n.Id, _ => new List<NetworkEdge>(), StringComparer.OrdinalIgnoreCase);
        foreach (var edge in graph.Edges)
            if (map.ContainsKey(edge.Source) && map.ContainsKey(edge.Target) && !string.Equals(edge.Source, edge.Target, StringComparison.OrdinalIgnoreCase))
            { map[edge.Source].Add(edge); map[edge.Target].Add(edge); }
        return map;
    }

    private static int CountComponents(NetworkGraph graph)
    {
        var adjacency = BuildAdjacency(graph);
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        int count = 0;
        foreach (var node in adjacency.Keys)
        {
            if (!seen.Add(node)) continue;
            count++;
            var queue = new Queue<string>();
            queue.Enqueue(node);
            while (queue.Count > 0)
                foreach (var next in adjacency[queue.Dequeue()])
                    if (seen.Add(next)) queue.Enqueue(next);
        }
        return count;
    }
}
