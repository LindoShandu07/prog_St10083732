# Smart-X Network Monitoring, Topology and Mesh Routing — Implementation Report

**Course:** Programming 3B (PROG7312)  
**Student:** Lindokuhle Mbatha  
**Platform:** C# / .NET 10, ASP.NET Core Web API, Windows Forms

## 1. Purpose and scope

This report describes the implemented Smart-X desktop client and API. It records existing features and the new tree, graph, traversal, MST and historical-range-query work added to the project. The project is a demonstrator using in-memory data. Its graph supports optional link measurements and calculates a composite routing cost; missing device metrics use explicitly flagged demonstration defaults. It is not yet connected to physical ESP32 radio measurements or persistent cloud storage.

## 2. Architecture

The solution has two executable projects:

- `SystemXsystem_API`: ASP.NET Core Web API. Controllers expose device, telemetry, command, dashboard, insight and topology operations. Services own shared data, telemetry processing, suggestions and graph algorithms.
- `SystemXsystem1`: Windows Forms client. `MainForm` integrates Dashboard, Sensor Ingestion, Command Stream and Network Topology in one sidebar-driven application. `ApiClient` performs asynchronous HTTP requests.

The API registers `SmartXDataStore`, `InsightEngine` and `NetworkGraphService` as singleton services and runs `TelemetryProcessor` as a hosted background service. The store protects shared in-memory collections with a common lock.

## 3. Data structures

| Structure | Implementation | Purpose | Typical complexity |
|---|---|---|---|
| Dictionary | `Dictionary<string, Device>` | Device lookup by case-insensitive ID/MAC | O(1) average lookup |
| AVL tree | `TelemetryHistoryIndex` backed by `AvlTree<TelemetryHistoryKey, TelemetryPacket>` | Timestamp-ordered history, with global and per-device indexes | O(log n) insert/remove; O(log n + k) bounded range retrieval |
| Queue | `Queue<TelemetryPacket>` | FIFO normal telemetry | O(1) enqueue/dequeue |
| PriorityQueue | `PriorityQueue<TelemetryPacket,int>` | Urgent telemetry first (smaller priority number first) | O(log n) enqueue/dequeue |
| Stack | `Stack<CommandLog>` | Last-in-first-out undo history | O(1) push/pop |
| HashSet | `HashSet<string>` | Unique active-error/disconnected nodes | O(1) average add/contains |
| Tree | `NetworkTreeNode` | Gateway → zones → devices hierarchy | O(V) construction/traversal |
| Graph | `NetworkGraph` adjacency derived from edge list | Model gateway, zones, devices and peer links | O(V + E) traversal |

## 4. Tree structures: topology and historical telemetry

The application uses two different tree structures for two different purposes:

1. `NetworkGraphService.BuildTree` builds the explicit gateway → zones → devices hierarchy used by the topology module. This is a domain tree and is not claimed to self-balance.
2. `TelemetryHistoryIndex` uses a genuine AVL search tree to index historical telemetry by timestamp. The AVL tree stores a height on each node and performs left, right, left-right and right-left rotations after insertions and removals to keep the balance factor between -1 and +1.

Each telemetry key contains the UTC timestamp ticks and a monotonically increasing sequence number. The sequence number allows two readings with the same timestamp to be stored without changing the timestamp on the original packet. The history index maintains one global AVL tree and a separate AVL tree for each device. This makes a device-specific query operate on that device's index rather than scanning unrelated devices.

The store retains up to 100,000 records in memory. When the limit is exceeded, the oldest key is removed from both the global index and its device index. This is bounded in-memory retention, not permanent storage; records are cleared when the API process restarts.

## 5. Graph model and cost-aware link weights

`NetworkGraphService.BuildGraph` creates vertices for the gateway, zones and devices. It creates gateway-to-zone edges, zone-to-device edges and same-zone peer edges. Each `NetworkEdge` carries a composite routing cost plus its component metrics: estimated/measured energy per transmission (mJ), latency (ms), packet loss (%) and signal strength (dBm).

The normalised routing score is:

```text
cost = 0.50 × (energy_mJ / 100)
     + 0.30 × (latency_ms / 200)
     + 0.20 × (packet_loss_percent / 100)
```

Lower cost is preferred. Energy has a 50% influence, latency 30%, and packet loss 20%. The reference values normalise different units into a dimensionless score. Inputs are bounded to prevent invalid or extreme values from dominating the calculation. Signal strength is included as diagnostic metadata; it is not independently added to the score because its practical impact is reflected by latency and packet loss.

`Device` supports optional `EnergyCostMilliJoules`, `LinkLatencyMs`, `PacketLossPercent` and `SignalStrengthDbm` values. If any required metric is absent, the graph builder supplies a documented demonstration default and sets `UsesSimulatedMetrics = true` on that edge. This flag is essential: the current seeded project is a simulation, not a real ESP32 radio measurement system. A future hardware integration should populate these fields from measured link telemetry and retain timestamps/measurement confidence.

The MST result reports total composite cost, total energy cost, average latency and average packet loss across selected edges. This makes the routing result easier to interpret than a single opaque weight.
 
### Core routing-cost implementation example

```csharp
double score = 0.50 * (energyMilliJoules / 100.0)
             + 0.30 * (latencyMs / 200.0)
             + 0.20 * (packetLossPercent / 100.0);
```

For example, a link with 12 mJ energy cost, 8 ms latency and 0.2% packet loss receives a cost of approximately `0.0724`. A link with a higher score is less attractive to Prim's algorithm, all else being equal. These are illustrative input values for the regression test, not measurements from physical hardware.

## 6. Traversal algorithms

The `GET /api/topology/algorithms/traverse` endpoint supports:

- Breadth-First Search (BFS): uses a `Queue<string>` and visits nodes level by level.
- Depth-First Search (DFS): uses a `Stack<string>` and explores a branch before backtracking.

Both algorithms use a visited `HashSet<string>` to prevent revisiting vertices. Their expected time complexity is O(V + E) for adjacency-list traversal.

## 7. Minimum Spanning Tree

`GET /api/topology/algorithms/mst` runs Prim's algorithm. A priority queue selects the lowest-cost frontier edge connecting the visited portion to an unvisited vertex. A sequence number breaks equal-cost ties deterministically. The result includes selected edges, total composite cost, total selected-link energy, average latency, average packet loss, connected-component count and an `IsSpanningTree` indicator. If a graph is disconnected, the implementation returns a minimum spanning forest and reports that it is not one spanning tree.

With adjacency lists and a priority queue, the implementation is O((V + E) log E) in the general edge-list representation. It minimises the sum of the supplied composite edge costs; it does not guarantee a globally optimal solution for every multi-objective wireless-routing problem. The quality of the result depends on the quality of the metrics. Demo defaults are explicitly marked simulated and must not be presented as measured radio performance.

## 8. Historical telemetry range queries

`GET /api/telemetry/history` supports optional `deviceId`, `take`, `fromUtc` and `toUtc` query parameters. Date boundaries are interpreted as timestamps and converted to UTC. The API rejects a range where `fromUtc` is later than `toUtc`. The Sensor Ingestion screen now provides From and To date pickers and a Query range button. The chart remains the existing timeline chart.

`TelemetryHistoryIndex.Query` selects either the global AVL tree or the requested device's AVL tree. It starts at the newest end of the inclusive date range, collects up to `take` records, then reverses the collected list so the API response remains chronological. With a balanced AVL tree, the expected query cost is O(log n + k), where n is the number of records in the selected index and k is the number of returned records. Insert and removal are O(log n). Maintaining both global and per-device indexes uses O(n) additional index storage and makes ingestion perform two AVL insertions.

The previous implementation used `SortedDictionary` but then called LINQ `Where` over `HistoricalLogs.Values`, which scanned the collection for every request. The new implementation uses tree navigation and a per-device index to avoid that full scan for bounded date queries.

### Core implementation example

The store now delegates history retrieval to the index instead of filtering every stored value:

```csharp
public List<TelemetryPacket> GetHistory(
    string? deviceId, int take,
    DateTime? fromUtc = null, DateTime? toUtc = null)
{
    lock (Sync)
    {
        return HistoricalLogs.Query(deviceId, take, fromUtc, toUtc);
    }
}
```

The AVL balancing operation updates the node height and applies rotations whenever the balance factor moves outside the range -1 to +1:

```csharp
private static Node Balance(Node node)
{
    UpdateHeight(node);
    int balance = BalanceFactor(node);

    if (balance > 1)
    {
        if (node.Left is not null && BalanceFactor(node.Left) < 0)
            node.Left = RotateLeft(node.Left);
        return RotateRight(node);
    }

    if (balance < -1)
    {
        if (node.Right is not null && BalanceFactor(node.Right) > 0)
            node.Right = RotateRight(node.Right);
        return RotateLeft(node);
    }

    return node;
}
```

### How the design scales

| Workload | Previous history query | AVL-indexed history |
|---|---|---|
| Insert one reading | O(log n) ordered-map insertion | O(log n) in each of two AVL indexes |
| Query all devices for a date range | O(n) filtering scan | O(log n + k) tree navigation and returned records |
| Query one device for a date range | O(n) scan plus device filtering | O(log n + k) in that device's AVL index |
| Evict oldest reading | O(log n) remove first key | O(log n) removal from global and device indexes |

Here, n is the number of records in the selected index and k is the number of records returned. The extra per-device index increases memory use, but avoids scanning unrelated devices. The 100,000-record retention cap bounds memory use for this in-memory demonstration. For histories larger than the retention window or for data that must survive restarts, the next step is durable time-series storage with indexed timestamp/device columns; the AVL index is an in-process query structure, not a replacement for a database.

Example:

```text
GET http://localhost:5000/api/telemetry/history?deviceId=24%3A6F%3A28%3AA1%3A00%3A01&take=5000&fromUtc=2026-11-01T00%3A00%3A00Z&toUtc=2026-11-05T23%3A59%3A59Z
```

The history remains in memory and is capped at 100,000 records. When the cap is reached, the oldest record is evicted. A process restart clears the history.

## 9. Existing functionality preserved

The upgrade retains device registration, demo-device seeding, telemetry validation, normal and priority queues, background processing, active-error de-duplication, command execution and undo, dashboard notifications, insight generation, API connectivity and the four existing main-menu modules.

## 10. Main-menu integration

The existing sidebar remains the application's primary navigation. The Sensor Ingestion module now includes date-range query controls. The Network Topology module includes Run BFS, Run DFS and Calculate MST actions. The topology canvas remains available alongside those controls.

## 11. Architecture health

`GET /api/health` returns a structured health response including API status, uptime, registered and online device counts, active errors, telemetry history size, and current graph node/edge counts. This is an application-level health snapshot, not a complete production observability stack. Production monitoring should add structured logs, metrics, tracing, readiness/liveness probes and alerting.

## 12. Automated verification and verification plan

A package-free regression runner is included in `SystemXsystem_API.Tests`. Run it from the `SystemXsystem` folder:

```powershell
dotnet run --project .\SystemXsystem_API.Tests\SystemXsystem_API.Tests.csproj
```

The runner checks equal timestamps, inclusive date boundaries, case-insensitive per-device indexing, latest-N chronological ordering, synchronized oldest-record eviction, and a 50,000-reading ordered-insertion workload with a 100-record range query. It also checks BFS/DFS reachability, Prim's preference for lower composite costs, disconnected minimum spanning forests, and metric/simulation flags in the graph builder. It prints elapsed times for the workload; those measurements should be recorded from the target machine and should not be represented as universal benchmark results.

Run the API and client on Windows with the .NET 10 SDK installed. Verify:

1. `GET /api/health` returns `success: true` and `status: healthy`.
2. `GET /api/topology/algorithms/tree` returns gateway → zones → devices.
3. `GET /api/topology/algorithms/graph` returns vertices and weighted edges.
4. `GET /api/topology/algorithms/traverse?startNode=gateway&method=BFS` returns BFS order.
5. Repeat with `method=DFS` and compare traversal order.
6. `GET /api/topology/algorithms/mst` returns a connected spanning tree for the seeded sample graph.
7. Submit normal and critical telemetry and verify existing FIFO/priority behaviour remains available.
8. Query history with a device and date range; confirm out-of-range readings are excluded.
9. Execute an actuator command and undo it.
10. Navigate between all four modules and verify refresh remains responsive.

No successful local compilation or execution is claimed in this report unless the developer runs these checks on the target Windows environment. The current authoring environment does not have the .NET SDK installed.

## 13. Limitations and next steps

- All devices and telemetry are in-memory; add SQL/Cosmos DB persistence for restart safety and larger history.
- Missing wireless metrics use demonstration defaults and are marked with `UsesSimulatedMetrics`; integrate measured ESP32 energy, latency, packet-loss and RSSI data before claiming real-world route optimisation.
- The current MST optimises the sum of supplied edge costs. A real wireless network may need constraints for reliability, latency, bandwidth, energy and gateway capacity.
- Extend automated tests to cover AVL rotations and balance invariants, BFS, DFS, Prim, disconnected graphs, concurrent ingestion and API-level history requests.
- Add authentication, authorisation, HTTPS, configuration-based endpoints and production logging before deployment.


## 13. Verified build and regression results (student-run evidence)

The student reported running the following commands from the `SystemXsystem` solution directory:

```powershell
dotnet run --project .\SystemXsystem_API.Tests\SystemXsystem_API.Tests.csproj
dotnet build .\SystemXsystem.sln
```

The regression runner reported **10/10 tests passed**, covering six telemetry-history cases and four graph cases. The subsequent full solution build succeeded for `SystemXsystem1` (`net10.0-windows`), `SystemXsystem_API` (`net10.0`) and `SystemXsystem_API.Tests` (`net10.0`).

The latest reported performance output was:

```text
50,000 inserts: 156 ms; 100-result range query: 0 ms
10/10 tests passed.
Build succeeded in 2.3s
```

The query time is displayed at millisecond resolution and should be interpreted as below 1 ms for that run, not a guarantee of zero execution time. These are student-machine observations, not controlled benchmarks. Include hardware/OS/SDK details and multiple-run medians if making a formal performance comparison.

## 14. Remaining manual verification

The successful build and regression tests do not independently verify every UI workflow. Complete `Documentation/FINAL_VERIFICATION_CHECKLIST.md` before submission. In particular, capture the actual `/api/health` response, navigate through all four modules, test API disconnect/reconnect, query history in the UI, issue/undo a command and demonstrate BFS, DFS and MST.

The exact original lecturer comments should be copied into `Documentation/ITERATIVE_FEEDBACK_LEDGER.md`. The current ZIP did not include the original feedback document, so the ledger labels its improvement themes as inferred from the project changes rather than quoting the lecturer.
