using SystemXsystem_API.Models;

namespace SystemXsystem_API.Services;

/// <summary>
/// Automated action engine. Combines three signals:
///  1. Learned patterns: what the operator did (command / search) after earlier alerts on a device.
///  2. Trend analysis: sensors drifting toward a threshold, flagged before they become critical.
///  3. Rule-based fallbacks for brand-new alerts that have no history yet.
/// </summary>
public class InsightEngine
{
    private readonly SmartXDataStore _store;

    public InsightEngine(SmartXDataStore store) => _store = store;

    public List<Insight> Generate()
    {
        lock (_store.Sync)
        {
            var insights = new List<Insight>();
            AddAlertInsights(insights);
            AddTrendInsights(insights);
            AddWorkflowInsights(insights);

            return insights
                .OrderBy(i => SeverityRank(i.Severity))
                .Take(8)
                .ToList();
        }
    }

    private static int SeverityRank(string severity) => severity switch
    {
        "critical" => 0,
        "warning" => 1,
        _ => 2
    };

    private void AddAlertInsights(List<Insight> insights)
    {
        foreach (var id in _store.ActiveErrorNodes)
        {
            if (!_store.LiveDevices.TryGetValue(id, out var device)) continue;

            // 1. Learned pattern for this device, most frequent first.
            var learned = _store.Patterns.Values
                .Where(p => string.Equals(p.TriggerDevice, id, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(p => p.Count)
                .FirstOrDefault();

            if (learned != null)
            {
                string targetName = NameOf(learned.Target);
                if (learned.Kind == "command")
                {
                    insights.Add(new Insight
                    {
                        Title = $"Suggested: turn {learned.Command} {targetName}",
                        Detail = $"{device.Name} is in alert. After previous alerts on this device you sent '{learned.Command}' to {targetName} ({learned.Count}x).",
                        Severity = "critical",
                        DeviceId = id,
                        SuggestedTarget = learned.Target,
                        SuggestedCommand = learned.Command
                    });
                }
                else
                {
                    insights.Add(new Insight
                    {
                        Title = $"Check {targetName}",
                        Detail = $"{device.Name} is in alert. You usually look up {targetName} next ({learned.Count}x).",
                        Severity = "critical",
                        DeviceId = id,
                        SuggestedTarget = learned.Target
                    });
                }
                continue;
            }

            // 3. No history yet: rule-based suggestion using devices in the same zone.
            insights.Add(RuleBasedAlertInsight(device));
        }
    }

    private Insight RuleBasedAlertInsight(Device device)
    {
        Device? SameZone(params string[] types) => _store.LiveDevices.Values.FirstOrDefault(d =>
            string.Equals(d.Zone, device.Zone, StringComparison.OrdinalIgnoreCase)
            && types.Contains(d.Type) && d.State != "DISCONNECTED");

        if (device.State == "DISCONNECTED")
        {
            return new Insight
            {
                Title = $"Investigate {device.Name}",
                Detail = $"{device.Name} stopped reporting. Check its power and Wi-Fi link.",
                Severity = "critical",
                DeviceId = device.Id
            };
        }

        Device? helper = null;
        string command = "ON";
        string reason = "";

        switch (device.Type)
        {
            case DeviceTypes.MoistureSensor:
                helper = SameZone(DeviceTypes.Pump, DeviceTypes.Valve);
                command = "ON";
                reason = "Moisture is critically low; start irrigation.";
                break;
            case DeviceTypes.PowerMeter:
                helper = SameZone(DeviceTypes.SmartPlug);
                command = "OFF";
                reason = "Power spike detected; cut the smart plug in this zone.";
                break;
            case DeviceTypes.TemperatureSensor:
                helper = SameZone(DeviceTypes.Pump, DeviceTypes.SmartPlug);
                command = "ON";
                reason = "Overheating; start cooling.";
                break;
        }

        return new Insight
        {
            Title = helper != null ? $"Suggested: turn {command} {helper.Name}" : $"Attention: {device.Name}",
            Detail = $"{device.Name} is in alert. {reason}",
            Severity = "critical",
            DeviceId = device.Id,
            SuggestedTarget = helper?.Id,
            SuggestedCommand = helper != null ? command : null
        };
    }

    private void AddTrendInsights(List<Insight> insights)
    {
        foreach (var device in _store.LiveDevices.Values)
        {
            if (_store.ActiveErrorNodes.Contains(device.Id)) continue;
            if (!_store.RecentReadings.TryGetValue(device.Id, out var queue) || queue.Count < 3) continue;

            var last3 = queue.Skip(queue.Count - 3).ToArray();
            bool falling = last3[0] > last3[1] && last3[1] > last3[2];
            bool rising = last3[0] < last3[1] && last3[1] < last3[2];
            double latest = last3[2];

            string? message = device.Type switch
            {
                DeviceTypes.MoistureSensor when falling && latest < 35 => $"Moisture is falling ({latest:0.#}%) and heading toward the 20% alert level.",
                DeviceTypes.PowerMeter when rising && latest > 1500 => $"Power draw is climbing ({latest:0.#} W) toward the 2000 W alert level.",
                DeviceTypes.TemperatureSensor when rising && latest > 45 => $"Temperature is climbing ({latest:0.#} °C) toward the 60 °C alert level.",
                _ => null
            };

            if (message != null)
            {
                insights.Add(new Insight
                {
                    Title = $"Watch {device.Name}",
                    Detail = message,
                    Severity = "warning",
                    DeviceId = device.Id
                });
            }
        }
    }

    private void AddWorkflowInsights(List<Insight> insights)
    {
        var top = _store.Patterns.Values
            .Where(p => p.Count >= 2 && !_store.ActiveErrorNodes.Contains(p.TriggerDevice))
            .OrderByDescending(p => p.Count)
            .FirstOrDefault();

        if (top == null) return;

        string action = top.Kind == "command"
            ? $"send '{top.Command}' to {NameOf(top.Target)}"
            : $"search for {NameOf(top.Target)}";

        insights.Add(new Insight
        {
            Title = "Learned workflow",
            Detail = $"When {NameOf(top.TriggerDevice)} raises an alert you tend to {action} ({top.Count}x).",
            Severity = "info",
            DeviceId = top.TriggerDevice,
            SuggestedTarget = top.Kind == "command" ? top.Target : null,
            SuggestedCommand = top.Kind == "command" ? top.Command : null
        });
    }

    private string NameOf(string idOrText)
    {
        if (_store.LiveDevices.TryGetValue(idOrText, out var d)) return d.Name;
        if (idOrText == "*") return "all actuators";
        if (idOrText.StartsWith("type:", StringComparison.OrdinalIgnoreCase)) return $"all {idOrText.Substring(5)}s";
        return idOrText;
    }
}
