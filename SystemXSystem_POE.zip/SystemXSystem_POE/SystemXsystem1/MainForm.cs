namespace SystemXsystem1;

/// <summary>Shell: sidebar navigation, connection bar, live toast and the four modules.</summary>
public class MainForm : Form
{
    private readonly ApiClient _api = new();

    private readonly DashboardPanel _dashboard;
    private readonly IngestionPanel _ingestion;
    private readonly CommandPanel _commands;
    private readonly TopologyPanel _topology;

    private readonly List<(string Title, Button Button, ModulePanel Panel)> _modules = new();
    private ModulePanel _active;

    private readonly Label _pageTitle = new();
    private readonly TextBox _urlBox = new();
    private readonly Label _connection = new();
    private readonly Label _toast = new();
    private readonly System.Windows.Forms.Timer _pollTimer = new() { Interval = 1500 };
    private readonly System.Windows.Forms.Timer _toastTimer = new() { Interval = 7000 };
    private bool _polling;
    private bool _refreshRequested;

    public MainForm()
    {
        Text = "SystemXsystem Client";
        Size = new Size(1280, 800);
        MinimumSize = new Size(1050, 680);
        StartPosition = FormStartPosition.CenterScreen;
        AutoScaleMode = AutoScaleMode.Dpi;
        Font = Theme.Body;
        BackColor = Theme.Bg;

        _dashboard = new DashboardPanel(_api);
        _ingestion = new IngestionPanel(_api);
        _commands = new CommandPanel(_api);
        _topology = new TopologyPanel(_api);
        _active = _dashboard;

        // Docking order: the Fill control is added first, then Top/Left controls (see WinForms z-order docking).
        var content = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Bg };
        content.Controls.Add(_topology);
        content.Controls.Add(_commands);
        content.Controls.Add(_ingestion);
        content.Controls.Add(_dashboard);
        Controls.Add(content);

        Controls.Add(BuildToast());
        Controls.Add(BuildHeader());
        Controls.Add(BuildSidebar());

        _dashboard.NotificationReceived += ShowToast;
        _toastTimer.Tick += (_, _) => { _toast.Visible = false; _toastTimer.Stop(); };
        _pollTimer.Tick += async (_, _) => await PollAsync();

        Shown += async (_, _) =>
        {
            ShowModule(_dashboard);
            _pollTimer.Start();
            await Task.CompletedTask;
        };

        FormClosing += (_, _) =>
        {
            _pollTimer.Stop();
            _toastTimer.Stop();
        };
    }

    // ------------------------------------------------------------- layout

    private Panel BuildSidebar()
    {
        var sidebar = new Panel { Dock = DockStyle.Left, Width = 220, BackColor = Theme.Sidebar };

        var items = new (string Title, ModulePanel Panel)[]
        {
            ("Dashboard", _dashboard),
            ("Sensor Ingestion", _ingestion),
            ("Command Stream", _commands),
            ("Network Topology", _topology)
        };

        foreach (var (title, panel) in items)
        {
            var button = new Button
            {
                Text = "   " + title,
                Dock = DockStyle.Top,
                Height = 50,
                FlatStyle = FlatStyle.Flat,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = Theme.Body,
                ForeColor = Color.FromArgb(203, 213, 225),
                BackColor = Theme.Sidebar,
                Cursor = Cursors.Hand,
                UseVisualStyleBackColor = false
            };
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = Theme.SidebarActive;
            var target = panel;
            button.Click += (_, _) => ShowModule(target);
            _modules.Add((title, button, panel));
        }

        // Later-added Top controls dock first, so add the buttons in reverse, then the brand last.
        for (int i = _modules.Count - 1; i >= 0; i--) sidebar.Controls.Add(_modules[i].Button);

        var brand = new Label
        {
            Text = "SystemXsystem",
            Dock = DockStyle.Top,
            Height = 76,
            Font = new Font("Segoe UI Semibold", 15f),
            ForeColor = Color.White,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(20, 0, 0, 0)
        };
        sidebar.Controls.Add(brand);
        return sidebar;
    }

    private Panel BuildHeader()
    {
        var header = new Panel { Dock = DockStyle.Top, Height = 64, BackColor = Theme.Card };

        _pageTitle.Font = Theme.Title;
        _pageTitle.ForeColor = Theme.Text;
        _pageTitle.AutoSize = true;
        _pageTitle.Location = new Point(20, 16);

        var urlLabel = Theme.MakeLabel("API URL", Theme.Small, Theme.Muted);
        _urlBox.Text = _api.BaseUrl;
        _urlBox.Width = 190;

        var connect = Theme.MakeButton("Connect", true, 90);
        connect.Height = 28;
        connect.Click += async (_, _) =>
        {
            _api.BaseUrl = _urlBox.Text.Trim();
            await PollAsync();
        };

        _connection.AutoSize = true;
        _connection.Font = Theme.Bold;

        // Right-aligned strip.
        var strip = new FlowLayoutPanel
        {
            Dock = DockStyle.Right,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Padding = new Padding(0, 16, 16, 0),
            BackColor = Theme.Card
        };
        urlLabel.Margin = new Padding(0, 6, 6, 0);
        _urlBox.Margin = new Padding(0, 3, 8, 0);
        connect.Margin = new Padding(0, 1, 16, 0);
        _connection.Margin = new Padding(0, 5, 0, 0);
        strip.Controls.AddRange(new Control[] { urlLabel, _urlBox, connect, _connection });

        header.Controls.Add(_pageTitle);
        header.Controls.Add(strip);
        return header;
    }

    private Panel BuildToast()
    {
        var holder = new Panel { Dock = DockStyle.Top, Height = 34, BackColor = Theme.Bg };
        _toast.Dock = DockStyle.Fill;
        _toast.Font = Theme.Bold;
        _toast.ForeColor = Color.White;
        _toast.TextAlign = ContentAlignment.MiddleLeft;
        _toast.Padding = new Padding(20, 0, 0, 0);
        _toast.Visible = false;
        holder.Controls.Add(_toast);
        return holder;
    }

    // ---------------------------------------------------------- behaviour

    private void ShowModule(ModulePanel panel)
    {
        _active = panel;
        foreach (var (title, button, p) in _modules)
        {
            bool isActive = p == panel;
            p.Visible = isActive;
            button.BackColor = isActive ? Theme.SidebarActive : Theme.Sidebar;
            button.ForeColor = isActive ? Color.White : Color.FromArgb(203, 213, 225);
            if (isActive) _pageTitle.Text = title;
        }
        panel.BringToFront();
        _ = PollAsync();
    }

    private async Task PollAsync()
    {
        // If a request is already in progress, remember that the active screen
        // needs a refresh and perform it as soon as the current pass completes.
        if (_polling)
        {
            _refreshRequested = true;
            return;
        }

        _polling = true;
        try
        {
            do
            {
                _refreshRequested = false;
                await _dashboard.RefreshAsync(); // keep feed and insights live on every screen

                // Capture the active panel for this pass. If navigation changes
                // during an await, the next coalesced pass refreshes the new panel.
                var panelToRefresh = _active;
                if (panelToRefresh != _dashboard)
                    await panelToRefresh.RefreshAsync();
            }
            while (_refreshRequested && !IsDisposed && !Disposing);

            SetConnection(true, "");
        }
        catch (ApiException ex)
        {
            SetConnection(false, ex.Message);
        }
        catch (Exception ex)
        {
            SetConnection(false, "Refresh failed: " + ex.Message);
        }
        finally
        {
            _polling = false;
        }
    }

    private void SetConnection(bool online, string message)
    {
        _connection.Text = online ? "● Connected" : "● Offline";
        _connection.ForeColor = online ? Theme.Success : Theme.Critical;
        if (!online)
            ShowBanner(message + " Start SystemXsystem_API, then press Connect.", Theme.Critical);
        else if (_toast.Visible && _toast.BackColor == Theme.Critical && !_toastTimer.Enabled)
            _toast.Visible = false;
    }

    private void ShowToast(NotificationDto notification)
    {
        ShowBanner(notification.Message, Theme.SeverityColor(notification.Severity));
        _toastTimer.Stop();
        _toastTimer.Start();
    }

    private void ShowBanner(string text, Color color)
    {
        _toast.Text = text;
        _toast.BackColor = color;
        _toast.Visible = true;
    }
}
