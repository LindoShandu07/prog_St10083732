# Final Integration and Submission Verification Checklist

Use this checklist on the Windows machine with the .NET 10 SDK. Mark an item only after personally completing it and capturing evidence where requested.

## A. Build and automated regression

- [x] Criterion 2 ZIP regression runner: 10/10 tests passed in the student's reported run.
- [x] Full solution build: desktop, API and test projects succeeded in the student's reported run.
- [ ] Re-run build and tests from the exact final submission folder after all changes.
- [ ] Save terminal screenshots showing the complete command and output.

Commands from `SystemXsystem`:

```powershell
dotnet restore .\SystemXsystem.sln
dotnet build .\SystemXsystem.sln
dotnet run --project .\SystemXsystem_API.Tests\SystemXsystem_API.Tests.csproj
```

## B. API and desktop integration

- [ ] Start API: `dotnet run --project .\SystemXsystem_API\SystemXsystem_API.csproj`
- [ ] Browse to `http://localhost:5000/api/health`; confirm `success: true` and `status: healthy`.
- [ ] Start desktop client in a second terminal: `dotnet run --project .\SystemXsystem1\SystemXsystem1.csproj`.
- [ ] Confirm top bar shows Connected.
- [ ] Navigate Dashboard, Sensor Ingestion, Command Stream and Network Topology.
- [ ] Stop the API temporarily; confirm the client reports Offline without crashing.
- [ ] Restart API and press Connect; confirm recovery.

## C. Functional demonstration

- [ ] Dashboard: confirm device counts, alerts/notifications and telemetry simulator.
- [ ] Sensor Ingestion: submit a normal reading and a critical reading.
- [ ] Sensor Ingestion: select a device and query a bounded date range.
- [ ] Command Stream: issue an actuator ON/OFF command and use Undo.
- [ ] Network Topology: run BFS and DFS from a valid start node.
- [ ] Network Topology: calculate MST and inspect selected edges, total cost and metrics.
- [ ] If graph edges use defaults, show/describe the simulated-metric indicator honestly.

## D. Evidence package

- [ ] Screenshot of the main menu and each of the four modules.
- [ ] Screenshot of `/api/health` JSON response.
- [ ] Screenshot of historical range query result.
- [ ] Screenshot of BFS, DFS and MST output.
- [ ] Screenshot of final build and 10/10 tests.
- [ ] Include exact lecturer feedback wording in `ITERATIVE_FEEDBACK_LEDGER.md`.
- [ ] Complete the personal reflection in `CHALLENGES_AND_LEARNINGS.md`.
- [ ] Verify README run instructions against the final folder layout.
- [ ] Include repository URL and ensure lecturer access; ZIP archives do not include Git commit history.

## E. Claims to avoid unless separately evidenced

- Do not claim measured ESP32 wireless optimisation while `UsesSimulatedMetrics` is true.
- Do not claim persistent history: the store is in memory and resets on API restart.
- Do not claim production security, cloud deployment, Kubernetes deployment or CI/CD unless implemented and demonstrated.
- Do not call a disconnected minimum spanning forest a single spanning tree.
