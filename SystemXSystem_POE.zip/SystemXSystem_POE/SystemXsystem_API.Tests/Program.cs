using System.Diagnostics;
using SystemXsystem_API.Models;
using SystemXsystem_API.Services;

// Lightweight, dependency-free regression tests for the AVL telemetry index.
// Run with: dotnet run --project SystemXsystem_API.Tests
var tests = new (string Name, Action Run)[]
{
    ("Equal timestamps are retained", EqualTimestampsAreRetained),
    ("Date boundaries are inclusive", DateRangeIsInclusive),
    ("Device-specific index returns only that device", DeviceIndexIsIsolated),
    ("Latest N results are returned chronologically", LatestResultsAreChronological),
    ("Oldest entry can be evicted", OldestEntryCanBeEvicted),
    ("Large ordered insert and range query complete", LargeOrderedHistoryWorks),
    ("BFS and DFS visit each reachable node once", GraphTraversalsVisitReachableNodes),
    ("Prim selects the lower composite-cost route", PrimSelectsLowerCostRoute),
    ("Disconnected graph returns a minimum spanning forest", DisconnectedGraphReturnsForest),
    ("Graph builder exposes link metrics and simulation flags", GraphBuilderExposesLinkMetrics)
};

int passed = 0;
foreach (var test in tests)
{
    try
    {
        test.Run();
        Console.WriteLine($"PASS: {test.Name}");
        passed++;
    }
    catch (Exception ex)
    {
        Console.WriteLine($"FAIL: {test.Name} - {ex.Message}");
        Environment.ExitCode = 1;
    }
}

Console.WriteLine($"\n{passed}/{tests.Length} tests passed.");

static TelemetryPacket Packet(string device, DateTime timestamp, double value) => new()
{
    DeviceId = device,
    Timestamp = timestamp,
    Value = value
};

static void Assert(bool condition, string message)
{
    if (!condition) throw new InvalidOperationException(message);
}

static void EqualTimestampsAreRetained()
{
    var index = new TelemetryHistoryIndex();
    var timestamp = DateTime.UtcNow;
    index.Add(Packet("sensor-A", timestamp, 10));
    index.Add(Packet("sensor-A", timestamp, 20));

    var result = index.Query("sensor-A", 10, timestamp, timestamp);
    Assert(index.Count == 2, "Both readings should be indexed.");
    Assert(result.Count == 2, "Both readings with the same timestamp should be returned.");
    Assert(result[0].Value == 10 && result[1].Value == 20, "Insertion order should break timestamp ties.");
}

static void DateRangeIsInclusive()
{
    var index = new TelemetryHistoryIndex();
    var start = new DateTime(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc);
    index.Add(Packet("sensor-A", start.AddMinutes(-1), 1));
    index.Add(Packet("sensor-A", start, 2));
    index.Add(Packet("sensor-A", start.AddMinutes(5), 3));
    index.Add(Packet("sensor-A", start.AddMinutes(6), 4));

    var result = index.Query("sensor-A", 20, start, start.AddMinutes(5));
    Assert(result.Count == 2, "The start and end timestamps should both be included.");
    Assert(result[0].Value == 2 && result[1].Value == 3, "Unexpected values in date range.");
}

static void DeviceIndexIsIsolated()
{
    var index = new TelemetryHistoryIndex();
    var time = DateTime.UtcNow;
    index.Add(Packet("sensor-A", time, 11));
    index.Add(Packet("sensor-B", time.AddTicks(1), 22));

    var result = index.Query("SENSOR-B", 10, null, null);
    Assert(result.Count == 1 && result[0].Value == 22, "Device lookup should be case-insensitive and isolated.");
}

static void LatestResultsAreChronological()
{
    var index = new TelemetryHistoryIndex();
    var start = DateTime.UtcNow;
    for (int i = 0; i < 20; i++)
        index.Add(Packet("sensor-A", start.AddSeconds(i), i));

    var result = index.Query("sensor-A", 3, null, null);
    Assert(result.Count == 3, "Expected exactly three readings.");
    Assert(result[0].Value == 17 && result[1].Value == 18 && result[2].Value == 19,
        "The newest three readings should be returned in ascending timestamp order.");
}

static void OldestEntryCanBeEvicted()
{
    var index = new TelemetryHistoryIndex();
    var start = DateTime.UtcNow;
    index.Add(Packet("sensor-A", start, 1));
    index.Add(Packet("sensor-B", start.AddSeconds(1), 2));

    Assert(index.RemoveOldest(), "An entry should have been removed.");
    Assert(index.Count == 1, "Global count should decrease after eviction.");
    Assert(index.Query("sensor-A", 10, null, null).Count == 0, "Evicted device entry must also leave its device index.");
    Assert(index.Query("sensor-B", 10, null, null).Count == 1, "The newer device entry should remain.");
}

static void LargeOrderedHistoryWorks()
{
    var index = new TelemetryHistoryIndex();
    var start = DateTime.UtcNow;
    const int total = 50_000;

    var stopwatch = Stopwatch.StartNew();
    for (int i = 0; i < total; i++)
        index.Add(Packet(i % 2 == 0 ? "sensor-A" : "sensor-B", start.AddTicks(i), i));
    stopwatch.Stop();
    var insertionMilliseconds = stopwatch.ElapsedMilliseconds;

    stopwatch.Restart();
    var result = index.Query("sensor-A", 100, start.AddTicks(total - 1000), start.AddTicks(total));
    stopwatch.Stop();

    Assert(index.Count == total, "All generated readings should be indexed.");
    Assert(result.Count == 100, "Expected the latest 100 matching sensor readings.");
    Assert(result.Zip(result.Skip(1), (a, b) => a.Timestamp <= b.Timestamp).All(x => x),
        "Results should be chronological.");

    Console.WriteLine($"  50,000 inserts: {insertionMilliseconds} ms; 100-result range query: {stopwatch.ElapsedMilliseconds} ms");
}


static void GraphTraversalsVisitReachableNodes()
{
    var service = new NetworkGraphService();
    var graph = new NetworkGraph();
    foreach (var id in new[] { "A", "B", "C", "D" }) graph.Nodes.Add(new NetworkNode { Id = id, Label = id });
    graph.Edges.Add(new NetworkEdge { Source = "A", Target = "B", Weight = 1 });
    graph.Edges.Add(new NetworkEdge { Source = "A", Target = "C", Weight = 1 });
    graph.Edges.Add(new NetworkEdge { Source = "B", Target = "D", Weight = 1 });

    var bfs = service.Traverse(graph, "A", "BFS");
    var dfs = service.Traverse(graph, "A", "DFS");
    Assert(bfs.VisitedCount == 4 && bfs.VisitedNodeIds.Distinct().Count() == 4, "BFS should visit all four nodes once.");
    Assert(dfs.VisitedCount == 4 && dfs.VisitedNodeIds.Distinct().Count() == 4, "DFS should visit all four nodes once.");
    Assert(bfs.VisitedNodeIds[1] == "B", "BFS should visit a direct neighbour before deeper nodes.");
}

static void PrimSelectsLowerCostRoute()
{
    var service = new NetworkGraphService();
    var graph = new NetworkGraph();
    foreach (var id in new[] { "A", "B", "C" }) graph.Nodes.Add(new NetworkNode { Id = id, Label = id });
    graph.Edges.Add(new NetworkEdge { Source = "A", Target = "B", Weight = 0.20, EnergyCostMilliJoules = 10, LatencyMs = 10, PacketLossPercent = 0.5 });
    graph.Edges.Add(new NetworkEdge { Source = "B", Target = "C", Weight = 0.30, EnergyCostMilliJoules = 15, LatencyMs = 20, PacketLossPercent = 1 });
    graph.Edges.Add(new NetworkEdge { Source = "A", Target = "C", Weight = 0.90, EnergyCostMilliJoules = 90, LatencyMs = 150, PacketLossPercent = 8 });

    var mst = service.MinimumSpanningTree(graph);
    Assert(mst.IsSpanningTree, "Connected three-node graph should produce a spanning tree.");
    Assert(mst.Edges.Count == 2, "A spanning tree of three nodes must contain two edges.");
    Assert(!mst.Edges.Any(e => e.Source == "A" && e.Target == "C"), "The expensive direct edge should not be selected.");
    Assert(Math.Abs(mst.TotalWeight - 0.50) < 0.000001, "Unexpected total MST cost.");
    Assert(mst.TotalEnergyCostMilliJoules == 25, "MST should report total energy cost.");
}

static void DisconnectedGraphReturnsForest()
{
    var service = new NetworkGraphService();
    var graph = new NetworkGraph();
    foreach (var id in new[] { "A", "B", "C", "D" }) graph.Nodes.Add(new NetworkNode { Id = id, Label = id });
    graph.Edges.Add(new NetworkEdge { Source = "A", Target = "B", Weight = 0.2 });
    graph.Edges.Add(new NetworkEdge { Source = "C", Target = "D", Weight = 0.3 });

    var result = service.MinimumSpanningTree(graph);
    Assert(!result.IsSpanningTree, "Disconnected graph must not be labelled as one spanning tree.");
    Assert(result.ComponentCount == 2 && result.Edges.Count == 2, "Expected a two-component minimum spanning forest.");
}

static void GraphBuilderExposesLinkMetrics()
{
    var service = new NetworkGraphService();
    var topology = new TopologyResponse
    {
        Gateway = "Test gateway",
        Zones =
        {
            new TopologyZone
            {
                Zone = "Lab",
                Devices =
                {
                    new Device { Id = "sensor-1", Name = "Sensor 1", State = "ONLINE", EnergyCostMilliJoules = 12, LinkLatencyMs = 8, PacketLossPercent = 0.2, SignalStrengthDbm = -45 },
                    new Device { Id = "sensor-2", Name = "Sensor 2", State = "ONLINE" }
                }
            }
        }
    };

    var graph = service.BuildGraph(topology);
    var measured = graph.Edges.Single(e => e.Source == "zone:Lab" && e.Target == "sensor-1");
    var simulated = graph.Edges.Single(e => e.Source == "zone:Lab" && e.Target == "sensor-2");
    Assert(!measured.UsesSimulatedMetrics, "Fully supplied link metrics should be marked measured.");
    Assert(simulated.UsesSimulatedMetrics, "Missing link metrics should be marked simulated.");
    Assert(measured.Weight < simulated.Weight, "Better link metrics should produce a lower routing cost.");
    Assert(measured.EnergyCostMilliJoules == 12 && measured.LatencyMs == 8, "Link metric values should be retained.");
}
