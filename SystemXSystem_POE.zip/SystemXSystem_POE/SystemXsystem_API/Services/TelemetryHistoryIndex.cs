namespace SystemXsystem_API.Services;

/// <summary>
/// AVL-tree-backed telemetry index. It keeps one chronological index for all
/// telemetry and a second index per device, so device-specific date queries do
/// not need to scan readings belonging to other devices.
/// </summary>
public sealed class TelemetryHistoryIndex
{
    private readonly AvlTree<TelemetryHistoryKey, Models.TelemetryPacket> _all = new();
    private readonly Dictionary<string, AvlTree<TelemetryHistoryKey, Models.TelemetryPacket>> _byDevice =
        new(StringComparer.OrdinalIgnoreCase);
    private long _sequence;

    public int Count => _all.Count;

    /// <summary>Adds a reading. Sequence breaks ties when timestamps are identical.</summary>
    public void Add(Models.TelemetryPacket packet)
    {
        ArgumentNullException.ThrowIfNull(packet);

        var timestamp = packet.Timestamp.ToUniversalTime();
        var key = new TelemetryHistoryKey(timestamp.Ticks, ++_sequence);

        _all.Add(key, packet);
        if (!_byDevice.TryGetValue(packet.DeviceId, out var deviceTree))
        {
            deviceTree = new AvlTree<TelemetryHistoryKey, Models.TelemetryPacket>();
            _byDevice[packet.DeviceId] = deviceTree;
        }
        deviceTree.Add(key, packet);
    }

    /// <summary>
    /// Removes the oldest global reading and its matching per-device entry.
    /// Returns false when the index is empty.
    /// </summary>
    public bool RemoveOldest()
    {
        if (!_all.TryRemoveMinimum(out var key, out var packet))
            return false;

        if (_byDevice.TryGetValue(packet.DeviceId, out var deviceTree))
        {
            deviceTree.Remove(key);
            if (deviceTree.Count == 0)
                _byDevice.Remove(packet.DeviceId);
        }
        return true;
    }

    /// <summary>
    /// Returns the newest matching readings within an inclusive UTC date range,
    /// in chronological order. The relevant AVL index is traversed backwards,
    /// stopping as soon as the requested number of matches has been collected.
    /// </summary>
    public List<Models.TelemetryPacket> Query(
        string? deviceId, int take, DateTime? fromUtc, DateTime? toUtc)
    {
        take = Math.Clamp(take, 1, 5000);

        // Keep the sentinel bounds exact; converting DateTime.MinValue/MaxValue
        // through the machine's local timezone can shift them and exclude data.
        var minTicks = fromUtc.HasValue ? fromUtc.Value.ToUniversalTime().Ticks : DateTime.MinValue.Ticks;
        var maxTicks = toUtc.HasValue ? toUtc.Value.ToUniversalTime().Ticks : DateTime.MaxValue.Ticks;
        if (minTicks > maxTicks)
            throw new ArgumentException("The start of the telemetry range must not be after its end.");

        var min = new TelemetryHistoryKey(minTicks, long.MinValue);
        var max = new TelemetryHistoryKey(maxTicks, long.MaxValue);

        AvlTree<TelemetryHistoryKey, Models.TelemetryPacket> tree;
        if (!string.IsNullOrWhiteSpace(deviceId))
        {
            if (!_byDevice.TryGetValue(deviceId, out tree!))
                return new List<Models.TelemetryPacket>();
        }
        else
        {
            tree = _all;
        }

        return tree.GetLatestInRange(min, max, take);
    }
}

/// <summary>Composite chronological key; sequence makes equal timestamps unique.</summary>
internal readonly record struct TelemetryHistoryKey(long TimestampTicks, long Sequence)
    : IComparable<TelemetryHistoryKey>
{
    public int CompareTo(TelemetryHistoryKey other)
    {
        int timestampComparison = TimestampTicks.CompareTo(other.TimestampTicks);
        return timestampComparison != 0
            ? timestampComparison
            : Sequence.CompareTo(other.Sequence);
    }
}

/// <summary>
/// Generic AVL tree. Insert, lookup and removal are O(log n); its height is
/// maintained after every mutation using single or double rotations.
/// </summary>
internal sealed class AvlTree<TKey, TValue> where TKey : notnull
{
    private sealed class Node(TKey key, TValue value)
    {
        public TKey Key { get; } = key;
        public TValue Value { get; } = value;
        public Node? Left { get; set; }
        public Node? Right { get; set; }
        public int Height { get; set; } = 1;
    }

    private readonly IComparer<TKey> _comparer = Comparer<TKey>.Default;
    private Node? _root;
    public int Count { get; private set; }

    public void Add(TKey key, TValue value)
    {
        bool added = false;
        _root = Insert(_root, key, value, ref added);
        if (!added)
            throw new InvalidOperationException("Duplicate AVL-tree key.");
        Count++;
    }

    public bool Remove(TKey key)
    {
        bool removed = false;
        _root = Delete(_root, key, ref removed);
        if (removed) Count--;
        return removed;
    }

    public bool TryRemoveMinimum(out TKey key, out TValue value)
    {
        if (_root is null)
        {
            key = default!;
            value = default!;
            return false;
        }

        Node minimum = FindMinimum(_root);
        key = minimum.Key;
        value = minimum.Value;
        Remove(key);
        return true;
    }

    public List<TValue> GetLatestInRange(TKey minimum, TKey maximum, int take)
    {
        var newestFirst = new List<TValue>(Math.Min(take, Count));
        CollectDescending(_root, minimum, maximum, take, newestFirst);
        newestFirst.Reverse();
        return newestFirst;
    }

    private Node Insert(Node? node, TKey key, TValue value, ref bool added)
    {
        if (node is null)
        {
            added = true;
            return new Node(key, value);
        }

        int comparison = _comparer.Compare(key, node.Key);
        if (comparison < 0) node.Left = Insert(node.Left, key, value, ref added);
        else if (comparison > 0) node.Right = Insert(node.Right, key, value, ref added);
        else return node;

        return Balance(node);
    }

    private Node? Delete(Node? node, TKey key, ref bool removed)
    {
        if (node is null) return null;

        int comparison = _comparer.Compare(key, node.Key);
        if (comparison < 0) node.Left = Delete(node.Left, key, ref removed);
        else if (comparison > 0) node.Right = Delete(node.Right, key, ref removed);
        else
        {
            removed = true;
            if (node.Left is null) return node.Right;
            if (node.Right is null) return node.Left;

            Node successor = FindMinimum(node.Right);
            node = new Node(successor.Key, successor.Value)
            {
                Left = node.Left,
                Right = DeleteMinimum(node.Right)
            };
        }

        return Balance(node);
    }

    private static Node? DeleteMinimum(Node node)
    {
        if (node.Left is null) return node.Right;
        node.Left = DeleteMinimum(node.Left);
        return Balance(node);
    }

    private void CollectDescending(Node? node, TKey minimum, TKey maximum,
        int take, List<TValue> results)
    {
        if (node is null || results.Count >= take) return;

        int againstMaximum = _comparer.Compare(node.Key, maximum);
        if (againstMaximum > 0)
        {
            CollectDescending(node.Left, minimum, maximum, take, results);
            return;
        }

        int againstMinimum = _comparer.Compare(node.Key, minimum);
        if (againstMinimum < 0)
        {
            CollectDescending(node.Right, minimum, maximum, take, results);
            return;
        }

        // Reverse in-order traversal finds the newest matching values first.
        CollectDescending(node.Right, minimum, maximum, take, results);
        if (results.Count < take) results.Add(node.Value);
        if (results.Count < take)
            CollectDescending(node.Left, minimum, maximum, take, results);
    }

    private static Node FindMinimum(Node node)
    {
        while (node.Left is not null) node = node.Left;
        return node;
    }

    private static int Height(Node? node) => node?.Height ?? 0;
    private static int BalanceFactor(Node node) => Height(node.Left) - Height(node.Right);

    private static void UpdateHeight(Node node) =>
        node.Height = 1 + Math.Max(Height(node.Left), Height(node.Right));

    private static Node Balance(Node node)
    {
        UpdateHeight(node);
        int balance = BalanceFactor(node);

        if (balance > 1)
        {
            if (node.Left is not null && BalanceFactor(node.Left) < 0)
                node.Left = RotateLeft(node.Left);
            return RotateRight(node);
        }

        if (balance < -1)
        {
            if (node.Right is not null && BalanceFactor(node.Right) > 0)
                node.Right = RotateRight(node.Right);
            return RotateLeft(node);
        }

        return node;
    }

    private static Node RotateRight(Node root)
    {
        Node pivot = root.Left!;
        root.Left = pivot.Right;
        pivot.Right = root;
        UpdateHeight(root);
        UpdateHeight(pivot);
        return pivot;
    }

    private static Node RotateLeft(Node root)
    {
        Node pivot = root.Right!;
        root.Right = pivot.Left;
        pivot.Left = root;
        UpdateHeight(root);
        UpdateHeight(pivot);
        return pivot;
    }
}
