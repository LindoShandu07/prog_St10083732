# Technology Recommendations and Rationale

## 1. Persistent telemetry storage

**Recommendation:** Azure SQL Database or Azure Cosmos DB.

**Rationale:** The current application stores device records, notifications and telemetry in memory. A process restart clears the data, and the history is capped. A persistent database would preserve readings, support larger time ranges, and allow multiple API instances to share a common data source.

- Choose Azure SQL Database when relational queries, reporting, transactions and structured device relationships are central.
- Consider Azure Cosmos DB when the telemetry workload is document-oriented, geographically distributed and requires flexible horizontal scaling.

The database should use indexes on device ID and timestamp to support historical range queries.

## 2. Message ingestion at higher scale

**Recommendation:** Azure Service Bus or Azure Event Hubs, depending on the workload.

**Rationale:** The current in-process queues are suitable for a single-instance teaching demonstrator but are lost when the API stops and are not shared between instances. A managed broker can decouple ingestion from processing, buffer bursts and support independent consumers.

- Service Bus is appropriate for reliable command/work queues and message delivery patterns.
- Event Hubs is more suitable for high-volume event/telemetry streams.

## 3. CI/CD and code quality

**Recommendation:** GitHub Actions.

**Rationale:** Automated workflows can restore dependencies, build the API and desktop solution, run tests and publish build artifacts whenever code is pushed. This reduces manual build mistakes and provides repeatable evidence of project quality. A Windows runner is needed for building and testing the Windows Forms project.

## 4. Observability and architecture health

**Recommendation:** Microsoft.Extensions.Logging with structured logs, OpenTelemetry metrics/traces, and a monitoring backend such as Azure Monitor/Application Insights.

**Rationale:** The current health endpoint returns a useful snapshot, but production operations also need request latency, error rates, queue depth, processing throughput, dependency failures and traces across the desktop/API boundary. Liveness and readiness endpoints should be separated when the service gains external dependencies.

## 5. Wireless mesh link measurement

**Recommendation:** Capture actual ESP32 link metrics such as RSSI, packet loss, latency and retransmission rate; normalise them into a documented edge cost.

**Rationale:** Prim's MST is only meaningful when edge weights represent a documented optimisation objective. The current implementation combines energy (50%), latency (30%) and packet loss (20%) after normalisation, and marks edges that rely on demonstration defaults. This demonstrates cost-aware selection while making the simulation boundary visible. A production deployment should feed timestamped ESP32 measurements into the link model, validate the weights against field tests and make the coefficients configurable for the network's reliability and battery-life priorities.

## 6. Natural-language operational summaries

**Recommendation:** Consider an LLM API only after the telemetry and alert data model is stable.

**Rationale:** A language model could summarise known alerts and trends for an operator, but it should not replace deterministic safety rules or directly execute actuator commands. Provide only the minimum necessary telemetry context, protect secrets and personal data, and require operator confirmation for control actions.

## 7. Security

**Recommendation:** Add authentication and role-based authorisation, HTTPS, secrets management, request validation and audit logging before deployment outside a trusted local demonstration environment.

**Rationale:** The current local API is designed for a development demonstration and does not implement production authentication. Device control endpoints should be restricted and auditable.

## 8. Scaling path

1. Keep the current single-machine design for classroom demonstration.
2. Add automated tests and structured logging.
3. Move telemetry and device state to persistent storage.
4. Introduce a managed message broker for ingestion bursts.
5. Run stateless API instances behind a load balancer.
6. Add metrics, tracing, alerting, authentication and deployment automation.
7. Replace demonstration defaults with timestamped measured wireless link data before claiming real mesh optimisation; keep the `UsesSimulatedMetrics` flag visible until measurements are available.


## 9. Recommendation comparison and selection rationale

| Capability | Suitable option | Why it fits | Decision point |
|---|---|---|---|
| Durable device/telemetry records | Azure SQL Database | Relational integrity, indexed device/timestamp queries, transactions and reporting | Prefer when relationships and SQL analytics dominate |
| Globally distributed flexible telemetry | Azure Cosmos DB | Document model and managed horizontal distribution | Prefer when access patterns and geographic distribution justify its cost/model |
| Reliable command work queues | Azure Service Bus | Queues, dead-lettering and reliable command delivery patterns | Prefer for commands and work items that need controlled delivery |
| High-throughput telemetry streams | Azure Event Hubs | Partitioned event ingestion for large event volumes | Prefer for telemetry streams and independent consumers |
| CI/CD | GitHub Actions | Repeatable restore/build/test workflow; Windows runner supports WinForms build | Add after test commands are stable and secrets are managed |
| Observability | OpenTelemetry + Azure Monitor/Application Insights | Correlated traces, metrics and logs across API operations | Add before operating multiple services or instances |
| Container orchestration | Azure Container Apps or AKS | Managed deployment and scaling for containerised API/worker services | Container Apps for simpler managed workloads; AKS only when Kubernetes control/ecosystem is needed |
| Security | ASP.NET Core authentication/authorization, HTTPS, managed secrets | Protects actuator commands and sensitive operational endpoints | Required before any network-exposed deployment |

## 10. Security and deployment sequence

1. Add authentication and role-based authorization; require an operator role for actuator commands.
2. Enforce HTTPS outside localhost development and store secrets in a managed secret store.
3. Add input validation, rate limiting, audit records and dependency scanning.
4. Add automated restore, build and test stages in GitHub Actions.
5. Containerise the API and background worker; do not attempt to containerise the Windows Forms client as though it were a web service.
6. Deploy the API/worker to an appropriate managed container platform; add persistent storage and a broker before scaling to multiple instances.
7. Add dashboards, alerts, tracing and tested backup/recovery procedures.

This sequence avoids introducing orchestration before the application has durable state, observable behaviour and a repeatable deployment pipeline. Kubernetes is not automatically the best first step: operational complexity should be justified by deployment scale, team capability and required control.
