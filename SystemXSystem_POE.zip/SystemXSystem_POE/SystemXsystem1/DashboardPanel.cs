namespace SystemXsystem1;

/// <summary>Landing page: live stats, notification feed, Suggested Actions and a telemetry simulator.</summary>
public class DashboardPanel : ModulePanel
{
    private readonly Dictionary<string, Label> _stats = new();
    private readonly ListBox _feed = new();
    private readonly ListBox _insights = new();
    private readonly Button _applyButton;
    private readonly Button _simButton;
    private readonly Label _status = new();
    private readonly System.Windows.Forms.Timer _simTimer = new() { Interval = 1000 };
    private readonly Random _rng = new();
    private readonly Dictionary<string, double> _simValues = new();

    private int _lastNoteId;
    private DateTime _serverStart;
    private string _insightKey = "";
    private bool _simBusy;

    public event Action<NotificationDto>? NotificationReceived;

    public DashboardPanel(ApiClient api) : base(api)
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = Theme.Bg };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 104));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        // --- toolbar
        var toolbar = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false };
        var seedButton = Theme.MakeButton("Load demo devices", false, 160);
        _simButton = Theme.MakeButton("Start simulation", true, 160);
        _status.AutoSize = true;
        _status.Font = Theme.Small;
        _status.ForeColor = Theme.Muted;
        _status.Margin = new Padding(12, 10, 0, 0);
        seedButton.Click += async (_, _) => await SeedAsync();
        _simButton.Click += (_, _) => ToggleSimulation();
        toolbar.Controls.AddRange(new Control[] { seedButton, _simButton, _status });
        _simTimer.Tick += async (_, _) => await SimulateTickAsync();

        // --- stat cards
        var stats = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 5, RowCount = 1, BackColor = Theme.Bg };
        for (int i = 0; i < 5; i++) stats.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        stats.Controls.Add(MakeStatCard("online", "Devices online"), 0, 0);
        stats.Controls.Add(MakeStatCard("alerts", "Active alerts"), 1, 0);
        stats.Controls.Add(MakeStatCard("priority", "Priority queue"), 2, 0);
        stats.Controls.Add(MakeStatCard("fifo", "Telemetry queue"), 3, 0);
        stats.Controls.Add(MakeStatCard("dups", "Duplicate alerts blocked"), 4, 0);

        // --- feed + insights
        var lists = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Theme.Bg };
        lists.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        lists.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

        var feedCard = Theme.MakeCard("Live notification feed");
        ConfigureList(_feed, 46, DrawFeedItem);
        feedCard.Controls.Add(_feed);
        feedCard.Controls.SetChildIndex(_feed, 0);

        var insightCard = Theme.MakeCard("Suggested Actions  -  Automated Insights");
        ConfigureList(_insights, 72, DrawInsightItem);
        _applyButton = Theme.MakeButton("Apply selected suggestion", true, 220);
        _applyButton.Dock = DockStyle.Bottom;
        _applyButton.Click += async (_, _) => await ApplySelectedAsync();
        _insights.DoubleClick += async (_, _) => await ApplySelectedAsync();
        insightCard.Controls.Add(_insights);
        insightCard.Controls.Add(_applyButton);
        insightCard.Controls.SetChildIndex(_insights, 0);

        lists.Controls.Add(feedCard, 0, 0);
        lists.Controls.Add(insightCard, 1, 0);

        root.Controls.Add(toolbar, 0, 0);
        root.Controls.Add(stats, 0, 1);
        root.Controls.Add(lists, 0, 2);
        Controls.Add(root);
    }

    private Panel MakeStatCard(string key, string caption)
    {
        var card = new Panel { BackColor = Theme.Card, Dock = DockStyle.Fill, Margin = new Padding(6), Padding = new Padding(14, 10, 14, 10) };
        var value = new Label { Text = "-", Font = Theme.Big, ForeColor = Theme.Text, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
        var label = new Label { Text = caption, Font = Theme.Small, ForeColor = Theme.Muted, Dock = DockStyle.Bottom, Height = 22 };
        card.Controls.Add(value);
        card.Controls.Add(label);
        _stats[key] = value;
        return card;
    }

    private static void ConfigureList(ListBox list, int itemHeight, DrawItemEventHandler draw)
    {
        list.Dock = DockStyle.Fill;
        list.BorderStyle = BorderStyle.None;
        list.BackColor = Theme.Card;
        list.DrawMode = DrawMode.OwnerDrawFixed;
        list.ItemHeight = itemHeight;
        list.IntegralHeight = false;
        list.DrawItem += draw;
    }

    // ------------------------------------------------------------ drawing

    private void DrawFeedItem(object? sender, DrawItemEventArgs e)
    {
        if (e.Index < 0 || e.Index >= _feed.Items.Count) return;
        var n = (NotificationDto)_feed.Items[e.Index];
        using (var bg = new SolidBrush(Theme.Card)) e.Graphics.FillRectangle(bg, e.Bounds);
        using (var bar = new SolidBrush(Theme.SeverityColor(n.Severity)))
            e.Graphics.FillRectangle(bar, e.Bounds.X, e.Bounds.Y + 5, 4, e.Bounds.Height - 10);

        TextRenderer.DrawText(e.Graphics, n.Time.ToLocalTime().ToString("HH:mm:ss"), Theme.Small,
            new Point(e.Bounds.X + 14, e.Bounds.Y + 5), Theme.Muted);
        TextRenderer.DrawText(e.Graphics, n.Message, Theme.Body,
            new Rectangle(e.Bounds.X + 14, e.Bounds.Y + 22, e.Bounds.Width - 20, 20), Theme.Text,
            TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
        using var line = new Pen(Theme.Line);
        e.Graphics.DrawLine(line, e.Bounds.X, e.Bounds.Bottom - 1, e.Bounds.Right, e.Bounds.Bottom - 1);
    }

    private void DrawInsightItem(object? sender, DrawItemEventArgs e)
    {
        if (e.Index < 0 || e.Index >= _insights.Items.Count) return;
        var item = (InsightDto)_insights.Items[e.Index];
        bool selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
        using (var bg = new SolidBrush(selected ? Color.FromArgb(240, 253, 250) : Theme.Card))
            e.Graphics.FillRectangle(bg, e.Bounds);
        using (var bar = new SolidBrush(Theme.SeverityColor(item.Severity)))
            e.Graphics.FillRectangle(bar, e.Bounds.X, e.Bounds.Y + 5, 4, e.Bounds.Height - 10);

        TextRenderer.DrawText(e.Graphics, item.Title, Theme.Bold,
            new Rectangle(e.Bounds.X + 14, e.Bounds.Y + 4, e.Bounds.Width - 20, 22), Theme.Text,
            TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
        TextRenderer.DrawText(e.Graphics, item.Detail, Theme.Small,
            new Rectangle(e.Bounds.X + 14, e.Bounds.Y + 26, e.Bounds.Width - 20, 40), Theme.Muted,
            TextFormatFlags.WordBreak | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
        using var line = new Pen(Theme.Line);
        e.Graphics.DrawLine(line, e.Bounds.X, e.Bounds.Bottom - 1, e.Bounds.Right, e.Bounds.Bottom - 1);
    }

    // ------------------------------------------------------------ refresh

    private bool _refreshing;

    public override async Task RefreshAsync()
    {
        if (_refreshing) return;   // avoid two overlapping refreshes inserting the same notifications twice
        _refreshing = true;
        try { await RefreshCoreAsync(); }
        finally { _refreshing = false; }
    }

    private async Task RefreshCoreAsync()
    {
        var summary = await Api.GetAsync<SummaryDto>("/api/dashboard");

        // The API was restarted (ids start again from 1): start the feed over.
        if (summary.StartedAtUtc != _serverStart)
        {
            _serverStart = summary.StartedAtUtc;
            _lastNoteId = 0;
            _feed.Items.Clear();
            _insightKey = "";
        }

        SetStat("online", $"{summary.OnlineDevices}/{summary.TotalDevices}", Theme.Text);
        SetStat("alerts", summary.ActiveErrors.ToString(), summary.ActiveErrors > 0 ? Theme.Critical : Theme.Success);
        SetStat("priority", summary.PriorityQueueLength.ToString(), Theme.Text);
        SetStat("fifo", summary.TelemetryQueueLength.ToString(), Theme.Text);
        SetStat("dups", summary.DuplicateAlertsSuppressed.ToString(), Theme.Info);

        var notes = await Api.GetAsync<List<NotificationDto>>($"/api/dashboard/notifications?since={_lastNoteId}");
        if (notes.Count > 0)
        {
            _feed.BeginUpdate();
            foreach (var n in notes)
            {
                _feed.Items.Insert(0, n);
                _lastNoteId = Math.Max(_lastNoteId, n.Id);
            }
            while (_feed.Items.Count > 100) _feed.Items.RemoveAt(_feed.Items.Count - 1);
            _feed.EndUpdate();
            NotificationReceived?.Invoke(notes[^1]);
        }

        var insights = await Api.GetAsync<List<InsightDto>>("/api/insights");
        if (insights.Count == 0)
            insights.Add(new InsightDto { Title = "All clear", Detail = "No alerts or risky trends detected right now.", Severity = "success" });
        string key = string.Join("||", insights.Select(i => i.Title + "|" + i.Detail));
        if (key != _insightKey)
        {
            _insightKey = key;
            int selected = _insights.SelectedIndex;
            _insights.BeginUpdate();
            _insights.Items.Clear();
            foreach (var i in insights) _insights.Items.Add(i);
            if (selected >= 0 && selected < _insights.Items.Count) _insights.SelectedIndex = selected;
            _insights.EndUpdate();
        }
    }

    private void SetStat(string key, string text, Color color)
    {
        _stats[key].Text = text;
        _stats[key].ForeColor = color;
    }

    // ------------------------------------------------------------ actions

    private async Task SeedAsync()
    {
        try
        {
            await Api.PostAsync("/api/devices/seed");
            SetStatus(_status, "Demo devices loaded.", "success");
            await RefreshAsync();
        }
        catch (ApiException ex) { SetStatus(_status, ex.Message, "critical"); }
    }

    private async Task ApplySelectedAsync()
    {
        if (_insights.SelectedItem is not InsightDto insight)
        {
            SetStatus(_status, "Select a suggestion first.", "warning");
            return;
        }
        if (!insight.CanApply)
        {
            SetStatus(_status, "This insight has no automatic action. It needs a manual check.", "warning");
            return;
        }

        try
        {
            await Api.PostAsync("/api/commands", new { target = insight.SuggestedTarget, command = insight.SuggestedCommand });
            SetStatus(_status, $"Applied: {insight.Title}", "success");
            await RefreshAsync();
        }
        catch (ApiException ex) { SetStatus(_status, ex.Message, "critical"); }
    }

    // --------------------------------------------------------- simulation

    private void ToggleSimulation()
    {
        if (_simTimer.Enabled)
        {
            _simTimer.Stop();
            _simButton.Text = "Start simulation";
            SetStatus(_status, "Simulation stopped.", "warning");
        }
        else
        {
            _simTimer.Start();
            _simButton.Text = "Stop simulation";
            SetStatus(_status, "Simulating sensor telemetry every second...", "success");
        }
    }

    private async Task SimulateTickAsync()
    {
        if (_simBusy) return;
        _simBusy = true;
        try
        {
            var devices = await Api.GetAsync<List<DeviceDto>>("/api/devices");
            foreach (var d in devices.Where(x => !x.IsActuator))
            {
                double value = NextSimValue(d);
                await Api.PostAsync("/api/telemetry", new { deviceId = d.Id, value = Math.Round(value, 1) });
            }
        }
        catch (ApiException ex)
        {
            _simTimer.Stop();
            _simButton.Text = "Start simulation";
            SetStatus(_status, "Simulation stopped: " + ex.Message, "critical");
        }
        finally { _simBusy = false; }
    }

    private double NextSimValue(DeviceDto d)
    {
        double value;
        switch (d.Type)
        {
            case "MoistureSensor":
                value = _simValues.TryGetValue(d.Id, out var m) ? m : 55 + _rng.NextDouble() * 15;
                value += -3.5 + _rng.NextDouble() * 3;          // drains about 2% per tick
                if (value < 5) value = 60 + _rng.NextDouble() * 10; // refilled
                break;
            case "PowerMeter":
                value = 400 + _rng.NextDouble() * 800;
                if (_rng.NextDouble() < 0.04) value = 2100 + _rng.NextDouble() * 700;  // occasional spike
                break;
            default:
                value = _simValues.TryGetValue(d.Id, out var t) ? t : 28;
                value += -1 + _rng.NextDouble() * 2.2;
                value = Math.Clamp(value, 20, 70);
                break;
        }
        _simValues[d.Id] = value;
        return value;
    }
}
