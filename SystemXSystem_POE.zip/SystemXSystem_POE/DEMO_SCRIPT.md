# Smart-X Demonstration Video Script

## 1. Start-up and connection

**Say:** "This is my Smart-X Network Monitoring and Management System. It has a Windows Forms client that communicates with an ASP.NET Core Web API. The API loads eight demonstration devices when it starts."

**Show:** Start the API, open the desktop client and point out the Connected status and dashboard cards.

## 2. Dashboard and collections

**Say:** "The dashboard displays device availability, active alerts, normal telemetry queue length, priority queue length and duplicate alerts suppressed. The backend uses a normal Queue for FIFO telemetry and a PriorityQueue so critical readings are processed first."

**Show:** Dashboard cards, notification feed and insights.

## 3. Sensor ingestion

**Say:** "I can register a node and submit sensor readings. A normal reading is queued for FIFO processing. A critical reading is identified against the configured threshold and is placed in the priority queue. Historical readings are stored in a SortedDictionary so they can be traversed chronologically."

**Show:** Send a normal moisture reading, then a critical sample; show the chart and status messages.

## 4. Alerts and suggestions

**Say:** "The Insight Engine checks active alerts, recent sensor trends and recorded operator actions. It combines rule-based suggestions with patterns from actions that followed previous alerts."

**Show:** Dashboard alert and suggestion. Explain that recommendations are rule/pattern-based rather than machine-learning predictions.

## 5. Commands and undo

**Say:** "The Command Stream lets an operator search for devices and send ON or OFF commands to actuators. A Stack stores the previous states so the latest command can be undone."

**Show:** Search Pump A, send ON, then press Undo and show the restored state.

## 6. Unique alert tracking

**Say:** "A HashSet stores unique active error node IDs. This prevents the same device from being added repeatedly while its alert remains active."

**Show:** Dashboard duplicate-alert counter and, if practical, submit repeated critical readings.

## 7. Network topology

**Say:** "The topology view currently represents the gateway, zones and devices in a hierarchy. Devices are colour-coded according to their current state. A weighted graph and Minimum Spanning Tree route calculation are possible future extensions; they are not part of this implementation."

**Show:** Network Topology screen and explain the gateway → zone → device structure.

## 8. Closing

**Say:** "The project demonstrates C# collections, asynchronous API communication, background telemetry processing, device management and automated operational insights. The current implementation uses in-memory storage, so persistent database storage is a future improvement."
