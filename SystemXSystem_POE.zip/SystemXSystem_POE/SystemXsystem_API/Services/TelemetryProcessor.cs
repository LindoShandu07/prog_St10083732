namespace SystemXsystem_API.Services;

/// <summary>Background worker that drains the priority queue and the FIFO queue and watches for silent sensors.</summary>
public class TelemetryProcessor : BackgroundService
{
    private readonly SmartXDataStore _store;
    private readonly ILogger<TelemetryProcessor> _logger;

    public TelemetryProcessor(SmartXDataStore store, ILogger<TelemetryProcessor> logger)
    {
        _store = store;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        int ticks = 0;
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                _store.ProcessPending();
                if (++ticks % 5 == 0) _store.CheckStaleDevices(TimeSpan.FromSeconds(45));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Telemetry processing failed");
            }

            try { await Task.Delay(200, stoppingToken); }
            catch (TaskCanceledException) { break; }
        }
    }
}
