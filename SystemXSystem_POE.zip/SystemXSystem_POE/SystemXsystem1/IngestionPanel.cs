using System.Drawing.Drawing2D;

namespace SystemXsystem1;

/// <summary>Sensor Ingestion: register nodes, push readings and see the timeline.</summary>
public class IngestionPanel : ModulePanel
{
    private static readonly string[] AllTypes = { "MoistureSensor", "TemperatureSensor", "PowerMeter", "Valve", "Pump", "SmartPlug" };

    private readonly TextBox _idBox = new();
    private readonly TextBox _nameBox = new();
    private readonly TextBox _zoneBox = new();
    private readonly ComboBox _typeBox = new();
    private readonly Label _registerStatus = new();

    private readonly ComboBox _deviceBox = new();
    private readonly NumericUpDown _valueBox = new();
    private readonly Label _sendStatus = new();

    private readonly TimelineChart _chart = new();
    private readonly Label _chartInfo = new();
    private readonly DateTimePicker _fromDate = new() { Format = DateTimePickerFormat.Short, Width = 115 };
    private readonly DateTimePicker _toDate = new() { Format = DateTimePickerFormat.Short, Width = 115 };

    private List<DeviceDto> _sensors = new();
    private string _deviceKey = "";

    public IngestionPanel(ApiClient api) : base(api)
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Theme.Bg };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 380));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        root.Controls.Add(BuildRegisterCard(), 0, 0);

        var right = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Theme.Bg };
        right.RowStyles.Add(new RowStyle(SizeType.Absolute, 170));
        right.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        right.Controls.Add(BuildSendCard(), 0, 0);
        right.Controls.Add(BuildChartCard(), 0, 1);
        root.Controls.Add(right, 1, 0);

        Controls.Add(root);
    }

    // ------------------------------------------------------------- layout

    private Panel BuildRegisterCard()
    {
        var card = Theme.MakeCard("Register a node");
        var form = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, AutoSize = false, BackColor = Theme.Card };

        _idBox.PlaceholderText = "MAC address or node id, e.g. 24:6F:28:A1:00:03";
        _nameBox.PlaceholderText = "Friendly name, e.g. Moisture Sensor C";
        _zoneBox.PlaceholderText = "Zone, e.g. Hydroponic Bay";
        _typeBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _typeBox.Items.AddRange(AllTypes);
        _typeBox.SelectedIndex = 0;

        var registerButton = Theme.MakeButton("Register node", true, 160);
        registerButton.Click += async (_, _) => await RegisterAsync();
        _registerStatus.AutoSize = false;
        _registerStatus.Height = 60;
        _registerStatus.Dock = DockStyle.Top;
        _registerStatus.Font = Theme.Small;

        AddField(form, "Node ID", _idBox);
        AddField(form, "Name", _nameBox);
        AddField(form, "Zone", _zoneBox);
        AddField(form, "Type", _typeBox);
        form.Controls.Add(registerButton);
        form.Controls.Add(_registerStatus);

        card.Controls.Add(form);
        card.Controls.SetChildIndex(form, 0);
        return card;
    }

    private Panel BuildSendCard()
    {
        var card = Theme.MakeCard("Send a telemetry reading");
        var flow = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = true, BackColor = Theme.Card };

        _deviceBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _deviceBox.Width = 300;
        _deviceBox.SelectedIndexChanged += async (_, _) => await LoadHistoryAsync();
        _valueBox.DecimalPlaces = 1;
        _valueBox.Minimum = -1000;
        _valueBox.Maximum = 100000;
        _valueBox.Value = 50;
        _valueBox.Width = 100;

        var sendButton = Theme.MakeButton("Send reading", true, 130);
        var criticalButton = Theme.MakeButton("Send critical sample", false, 170);
        sendButton.Click += async (_, _) => await SendAsync((double)_valueBox.Value);
        criticalButton.Click += async (_, _) => await SendAsync(CriticalSampleFor(SelectedSensor()));

        _sendStatus.AutoSize = false;
        _sendStatus.Width = 700;
        _sendStatus.Height = 24;
        _sendStatus.Font = Theme.Small;

        flow.Controls.Add(Wrap("Device", _deviceBox));
        flow.Controls.Add(Wrap("Value", _valueBox));
        flow.Controls.Add(Wrap(" ", sendButton));
        flow.Controls.Add(Wrap(" ", criticalButton));
        flow.Controls.Add(_sendStatus);

        card.Controls.Add(flow);
        card.Controls.SetChildIndex(flow, 0);
        return card;
    }

    private Panel BuildChartCard()
    {
        var card = Theme.MakeCard("Sensor timeline and historical range query");
        _chart.Dock = DockStyle.Fill;
        _chartInfo.Dock = DockStyle.Bottom;
        _chartInfo.Height = 22;
        _chartInfo.Font = Theme.Small;
        _chartInfo.ForeColor = Theme.Muted;
        _fromDate.Value = DateTime.Today.AddDays(-7);
        _toDate.Value = DateTime.Today;
        var rangeBar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 38, WrapContents = false, BackColor = Theme.Card };
        var queryButton = Theme.MakeButton("Query range", true, 110);
        queryButton.Click += async (_, _) => await LoadHistoryAsync(true);
        rangeBar.Controls.AddRange(new Control[] { Theme.MakeLabel("From", Theme.Small, Theme.Muted), _fromDate, Theme.MakeLabel("To", Theme.Small, Theme.Muted), _toDate, queryButton });
        card.Controls.Add(_chart);
        card.Controls.Add(_chartInfo);
        card.Controls.Add(rangeBar);
        card.Controls.SetChildIndex(_chart, 0);
        return card;
    }

    private static void AddField(TableLayoutPanel form, string caption, Control input)
    {
        var label = Theme.MakeLabel(caption, Theme.Small, Theme.Muted);
        label.Margin = new Padding(0, 8, 0, 2);
        input.Dock = DockStyle.None;
        input.Width = 330;
        input.Margin = new Padding(0, 0, 0, 4);
        form.Controls.Add(label);
        form.Controls.Add(input);
    }

    private static Control Wrap(string caption, Control input)
    {
        var panel = new FlowLayoutPanel { FlowDirection = FlowDirection.TopDown, AutoSize = true, WrapContents = false, Margin = new Padding(0, 0, 14, 0) };
        panel.Controls.Add(Theme.MakeLabel(caption, Theme.Small, Theme.Muted));
        panel.Controls.Add(input);
        return panel;
    }

    // ------------------------------------------------------------ actions

    private async Task RegisterAsync()
    {
        string id = _idBox.Text.Trim();
        string name = _nameBox.Text.Trim();
        if (id.Length == 0 || name.Length == 0)
        {
            SetStatus(_registerStatus, "Node ID and name are required.", "warning");
            return;
        }

        string type = (string)_typeBox.SelectedItem!;
        var (metric, unit) = type switch
        {
            "MoistureSensor" => ("Moisture", "%"),
            "TemperatureSensor" => ("Temperature", "°C"),
            "PowerMeter" => ("Power", "W"),
            _ => ("", "")
        };

        try
        {
            await Api.PostAsync("/api/devices", new
            {
                id,
                name,
                type,
                zone = string.IsNullOrWhiteSpace(_zoneBox.Text) ? "Unassigned" : _zoneBox.Text.Trim(),
                metric,
                unit
            });
            SetStatus(_registerStatus, $"Registered {name}.", "success");
            _idBox.Clear();
            _nameBox.Clear();
            await RefreshAsync();
        }
        catch (ApiException ex) { SetStatus(_registerStatus, ex.Message, "critical"); }
    }

    private async Task SendAsync(double value)
    {
        var sensor = SelectedSensor();
        if (sensor == null)
        {
            SetStatus(_sendStatus, "Register or load a sensor first (use Load demo devices on the Dashboard).", "warning");
            return;
        }

        try
        {
            var result = await Api.PostAsync<Dictionary<string, object?>>("/api/telemetry", new { deviceId = sensor.Id, value });
            string queue = result.TryGetValue("queued", out var q) ? q?.ToString() ?? "" : "";
            bool critical = queue == "priority";
            SetStatus(_sendStatus,
                critical ? $"{value:0.#} sent: CRITICAL, routed through the priority queue." : $"{value:0.#} sent: queued normally (FIFO).",
                critical ? "critical" : "success");
            await Task.Delay(350);   // let the processor drain the queue
            await LoadHistoryAsync();
        }
        catch (ApiException ex) { SetStatus(_sendStatus, ex.Message, "critical"); }
    }

    private DeviceDto? SelectedSensor() => _deviceBox.SelectedItem as DeviceDto;

    private static double CriticalSampleFor(DeviceDto? sensor) => sensor?.Type switch
    {
        "PowerMeter" => 2400,
        "TemperatureSensor" => 70,
        _ => 12
    };

    private async Task LoadHistoryAsync(bool useDateRange = false)
    {
        var sensor = SelectedSensor();
        if (sensor == null)
        {
            _chart.SetData(new List<PacketDto>(), "", "");
            _chartInfo.Text = "";
            return;
        }

        try
        {
            string range = useDateRange
                ? $"&fromUtc={Uri.EscapeDataString(_fromDate.Value.Date.ToUniversalTime().ToString("o"))}&toUtc={Uri.EscapeDataString(_toDate.Value.Date.AddDays(1).AddTicks(-1).ToUniversalTime().ToString("o"))}"
                : "";
            if (useDateRange && _fromDate.Value.Date > _toDate.Value.Date)
            {
                _chartInfo.Text = "The start date must be before the end date.";
                return;
            }
            var points = await Api.GetAsync<List<PacketDto>>($"/api/telemetry/history?deviceId={Uri.EscapeDataString(sensor.Id)}&take=5000{range}");
            _chart.SetData(points, sensor.Unit, sensor.Name);
            _chartInfo.Text = $"{points.Count} reading(s) from sorted history, oldest to newest. Red dots are critical readings.";
        }
        catch (ApiException ex) { _chartInfo.Text = ex.Message; }
    }

    public override async Task RefreshAsync()
    {
        var devices = await Api.GetAsync<List<DeviceDto>>("/api/devices");
        var sensors = devices.Where(d => !d.IsActuator).ToList();

        string key = string.Join(",", sensors.Select(s => s.Id));
        if (key != _deviceKey)
        {
            string? previous = SelectedSensor()?.Id;
            _deviceKey = key;
            _sensors = sensors;
            _deviceBox.Items.Clear();
            foreach (var s in sensors) _deviceBox.Items.Add(s);
            int index = sensors.FindIndex(s => s.Id == previous);
            if (_deviceBox.Items.Count > 0) _deviceBox.SelectedIndex = index >= 0 ? index : 0;
        }
        await LoadHistoryAsync();
    }
}

/// <summary>Small custom line chart for one sensor's history.</summary>
public class TimelineChart : Control
{
    private List<PacketDto> _points = new();
    private string _unit = "";
    private string _name = "";

    public TimelineChart()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
        BackColor = Theme.Card;
        Font = Theme.Small;
    }

    public void SetData(List<PacketDto> points, string unit, string name)
    {
        _points = points;
        _unit = unit;
        _name = name;
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;

        var plot = new Rectangle(56, 12, Width - 56 - 18, Height - 12 - 30);
        if (plot.Width < 40 || plot.Height < 40) return;

        if (_points.Count < 2)
        {
            TextRenderer.DrawText(g, _points.Count == 0 ? "No readings yet. Send a reading to see the timeline." : "Need at least 2 readings to draw a line.",
                Theme.Body, ClientRectangle, Theme.Muted, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            return;
        }

        double min = _points.Min(p => p.Value);
        double max = _points.Max(p => p.Value);
        if (Math.Abs(max - min) < 0.001) { min -= 1; max += 1; }
        double pad = (max - min) * 0.1;
        min -= pad;
        max += pad;

        DateTime t0 = _points.First().Timestamp;
        DateTime t1 = _points.Last().Timestamp;
        double span = Math.Max(1, (t1 - t0).TotalMilliseconds);

        PointF ToPoint(PacketDto p) => new(
            plot.Left + (float)((p.Timestamp - t0).TotalMilliseconds / span * plot.Width),
            plot.Bottom - (float)((p.Value - min) / (max - min) * plot.Height));

        using (var grid = new Pen(Theme.Line))
        {
            for (int i = 0; i <= 4; i++)
            {
                float y = plot.Top + plot.Height * i / 4f;
                g.DrawLine(grid, plot.Left, y, plot.Right, y);
                double value = max - (max - min) * i / 4.0;
                TextRenderer.DrawText(g, value.ToString("0.#"), Theme.Small, new Point(4, (int)y - 8), Theme.Muted);
            }
        }

        var pts = _points.Select(ToPoint).ToArray();
        using (var linePen = new Pen(Theme.Accent, 2f))
            g.DrawLines(linePen, pts);

        for (int i = 0; i < pts.Length; i++)
        {
            using var brush = new SolidBrush(_points[i].IsCritical ? Theme.Critical : Theme.Accent);
            g.FillEllipse(brush, pts[i].X - 4, pts[i].Y - 4, 8, 8);
        }

        TextRenderer.DrawText(g, t0.ToLocalTime().ToString("HH:mm:ss"), Theme.Small, new Point(plot.Left, plot.Bottom + 6), Theme.Muted);
        TextRenderer.DrawText(g, t1.ToLocalTime().ToString("HH:mm:ss"), Theme.Small, new Point(plot.Right - 50, plot.Bottom + 6), Theme.Muted);
        TextRenderer.DrawText(g, $"{_name} ({_unit})", Theme.Small, new Point(plot.Left + plot.Width / 2 - 60, plot.Bottom + 6), Theme.Muted);
    }
}
