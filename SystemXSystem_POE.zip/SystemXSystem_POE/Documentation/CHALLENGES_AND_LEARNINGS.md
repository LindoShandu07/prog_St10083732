# Challenges and Learnings

## Challenges encountered

### 1. Keeping the user interface responsive

The desktop client communicates with the API while users switch between modules. Asynchronous HTTP calls and a coalesced refresh process help prevent long network operations from freezing the interface or causing overlapping refresh work.

### 2. Coordinating shared collections

The API controllers and background telemetry processor access the same in-memory collections. The shared store uses a common lock around reads and writes to reduce race conditions while queues, dictionaries, sets and history are updated.

### 3. Prioritising critical events

A single FIFO queue would treat every reading equally. Separating urgent readings into a PriorityQueue demonstrates how critical events can be processed before routine telemetry.

### 4. Avoiding duplicate alerts

Repeated critical readings can create noisy dashboards. A HashSet tracks active error nodes so the system can suppress repeated alerts for a node that is already in an error state.

### 5. Supporting command reversal

Actuator commands change device state. The application stores previous states in a Stack so the latest command can be undone.

### 6. Modelling a network for graph algorithms

The initial topology was a hierarchy. Graph algorithms require vertices and weighted edges. The upgrade adds explicit graph models, peer links, BFS, DFS and Prim's MST. The graph now calculates a documented composite cost from energy, latency and packet-loss metrics. When a device does not supply all required measurements, the graph builder uses demonstration defaults and marks the affected edge with `UsesSimulatedMetrics`. This avoids presenting estimated values as physical radio measurements.

### 7. Querying history efficiently

Chronologically sorted telemetry supports ordered traversal. Date-range filters make the history more useful by allowing an operator to retrieve readings for a selected period and device.

## Technical learnings

- Select data structures based on the operations the application needs to perform.
- Use a queue for FIFO processing, a priority queue for urgency, a stack for undo, a dictionary for keyed lookup and a set for uniqueness.
- Use BFS and DFS to explore graph connectivity in different orders.
- Use Prim's algorithm to build a minimum spanning tree from weighted edges.
- Understand that graph algorithm results depend on the quality and meaning of the edge weights. A composite cost must be normalised, documented and validated against real measurements before it can guide physical routing.
- Use UTC timestamps consistently for telemetry and date-range APIs.
- Separate the UI, API controllers, domain models and services to make the solution easier to maintain.
- Validate application behaviour through repeatable test scenarios and recorded evidence.

## Personal reflection prompt

Before submitting, add a short paragraph in your own words describing which implementation was most difficult, how you debugged it, what you would redesign, and what you learned from the lecturer's formative feedback. This section should reflect your actual experience rather than claiming work or testing that was not performed.


## Engineering analysis: cause, response and trade-offs

| Engineering concern | Why it matters | Implemented response | Trade-off / remaining limitation |
|---|---|---|---|
| Ordered history queries | Filtering all readings for every request scales linearly with retained history | A global AVL index and per-device AVL indexes navigate directly to the requested timestamp range | Two indexes consume additional memory and each reading is inserted twice |
| Equal timestamps | Timestamp-only keys would collide when multiple readings share the same timestamp | A composite key uses UTC ticks plus a monotonically increasing sequence | Sequence is process-local and intended for the current in-memory lifetime |
| Retention | Unbounded in-memory history can exhaust memory | The store caps retained history and evicts the oldest record from both indexes | Restart loses history; persistence is a future requirement |
| Network route scoring | Energy, latency and packet loss use different units and cannot be added raw | Each metric is normalised and combined with documented weights | Weights are design assumptions; field testing is required to validate them |
| Disconnected mesh segments | A single MST cannot connect components that have no path between them | Prim is restarted for each unvisited component and returns a minimum spanning forest | The result is not one spanning tree when the graph is disconnected |
| UI refresh overlap | A slow API request can overlap the next timer tick or a navigation refresh | `MainForm.PollAsync` coalesces refresh requests while a poll is active | This is a single-client refresh strategy, not a distributed coordination mechanism |
| API shared state | Controllers and the hosted worker access shared in-memory collections | `SmartXDataStore` serialises collection access with a common lock | A single lock can limit throughput under high concurrency; a database/repository design is recommended at scale |

## Debugging and verification approach

The project includes a lightweight regression runner rather than relying only on manual demonstration. The current tests cover duplicate timestamps, inclusive date bounds, per-device isolation, chronological latest-N output, oldest-record eviction, a 50,000-record ordered workload, BFS/DFS reachability, Prim cost selection, disconnected components and graph metric/simulation flags.

The test runner is intentionally dependency-free. This keeps the assessment demonstration simple, but it is not a replacement for a full unit-testing framework, load test, concurrency stress test or end-to-end UI test.

## Student reflection — complete in your own words before submission

The following prompts are deliberately left for the student. Replace each bracketed instruction with what actually happened during your development; do not submit the prompts unchanged.

1. **Most difficult problem:** [Describe the specific bug or design issue you personally found most difficult.]
2. **How it was diagnosed:** [Describe the commands, debugger, logs, test cases or code inspection you actually used.]
3. **What changed:** [Name the classes/methods you changed and explain why the revised design is better.]
4. **What you learned:** [Explain one technical concept you understand better now, such as AVL rotations, range-query complexity, graph weights or async UI refresh.]
5. **What you would improve next:** [Identify a realistic next step, such as persistent storage, hardware-derived link metrics, concurrency tests or CI.]

Do not claim that hardware measurements, cloud deployment, production security or manual tests were completed unless you performed them and can provide evidence.
