# SystemXSystem POE — Part 3 Submission Guide

**Module:** Programming 3B (PROG7312)  
**Assessment:** Part 3  
**Total:** 100 marks

This guide maps the eight assessment criteria to the implementation and evidence in this package. It distinguishes source-code evidence, automated test evidence and manual/student evidence still required. A feature described in documentation must not be treated as verified until it has been run and demonstrated.

## 1. Rubric-to-project mapping

| Criterion | Marks | Implementation and evidence location | Current evidence / final action |
|---|---:|---|---|
| 1. Tree structures and historical telemetry queries | 30 | `SystemXsystem_API/Services/TelemetryHistoryIndex.cs`; `SmartXDataStore.cs`; `Documentation/IMPLEMENTATION_REPORT.md` | AVL tree with balancing rotations, global and per-device indexes, inclusive range query and eviction. Six history regression tests passed in the student's reported run. Re-run final package; capture test output. |
| 2. Graphs, traversals and MST | 30 | `SystemXsystem_API/Services/NetworkGraphService.cs`; `Documentation/CRITERION_2_GRAPH_IMPROVEMENTS.md` | BFS, DFS, Prim minimum spanning forest, deterministic tie-break, weighted energy/latency/loss score and simulated-metric flag. Four graph regression tests passed in the student's reported run. Demonstrate graph actions in the UI. |
| 3. README and code explanations | 10 | `README.md`; `Documentation/IMPLEMENTATION_REPORT.md`; `Documentation/ARCHITECTURE.mmd` | Architecture, code responsibilities, code examples, complexity discussion, endpoints, setup and test instructions are included. Confirm all commands against the final Windows environment. |
| 4. Challenges and learnings | 10 | `Documentation/CHALLENGES_AND_LEARNINGS.md` | Technical analysis is drafted. Student must add a genuine first-person reflection based on actual development/debugging experience; do not submit the prompt as if it were completed. |
| 5. Technology recommendations | 5 | `Documentation/TECHNOLOGY_RECOMMENDATIONS.md` | Recommendations cover persistent storage, ingestion pipelines, CI/CD, observability, measured wireless metrics, security and container deployment. Recommendations are future-facing, not claims of current deployment. |
| 6. Technology recommendations rationale | 5 | `Documentation/TECHNOLOGY_RECOMMENDATIONS.md` | Trade-offs and sequencing are explained. Keep the distinction between proposed technologies and implemented technologies. |
| 7. Iterative feedback incorporation | 5 | `Documentation/ITERATIVE_FEEDBACK_LEDGER.md` | Ledger links observed engineering improvements to files and tests. Student must paste exact lecturer feedback from the original formative feedback document and attach evidence. Current ledger themes are not verbatim lecturer comments. |
| 8. Main menu integration and architecture health | 5 | `SystemXsystem1/MainForm.cs`; `SystemXsystem_API/Program.cs`; `Documentation/FINAL_VERIFICATION_CHECKLIST.md` | Main form integrates Dashboard, Sensor Ingestion, Command Stream and Network Topology; asynchronous polling and `/api/health` are present. Student must manually navigate all modules and capture evidence from the final build. |

## 2. Important technical scope and honesty notes

- The application is a **Windows Forms desktop application with an ASP.NET Core API**, not an Android/mobile application.
- The history store is in memory. It is bounded and loses its contents when the API process restarts; persistent database storage is recommended future work.
- The graph cost combines energy (50%), latency (30%) and packet loss (20%) after normalisation. Missing device metrics are filled with demo values and marked `UsesSimulatedMetrics`. Do not describe those edges as measured physical wireless links.
- The insight engine is rule/pattern-based. Do not describe it as a trained AI model.
- The technology recommendations are proposed architecture, not deployed cloud infrastructure, Kubernetes, CI/CD or production security.
- Automated regression tests do not replace a manual end-to-end demonstration of the API and desktop UI.

## 3. Final Windows verification commands

Run these commands from the folder containing `SystemXsystem.sln`:

```powershell
dotnet --list-sdks
dotnet restore .\SystemXsystem.sln
dotnet build .\SystemXsystem.sln
dotnet run --project .\SystemXsystem_API.Tests\SystemXsystem_API.Tests.csproj
```

Expected test-runner summary for the current Criterion 2 version is `10/10 tests passed`. Treat that as an expected result, not as proof that the final extracted package has already been tested. Save the actual output from the final run.

Start the API and desktop app in separate terminals:

```powershell
dotnet run --project .\SystemXsystem_API\SystemXsystem_API.csproj
```

```powershell
dotnet run --project .\SystemXsystem1\SystemXsystem1.csproj
```

Open `http://localhost:5000/api/health` while the API is running.

## 4. Screenshots/evidence to capture

Save genuine screenshots from the final project run in an `Evidence` folder before submission:

1. Successful `dotnet build` output showing all three projects.
2. Regression runner output showing all 10 tests.
3. API `/api/health` response in a browser.
4. Desktop Dashboard with Connected status.
5. Sensor Ingestion showing a submitted reading and a historical date-range query.
6. Command Stream showing a command and its undo result.
7. Network Topology showing BFS output.
8. Network Topology showing DFS output.
9. Network Topology showing Prim MST result and its metrics/simulation status.
10. Screenshots showing navigation across all four modules.

Do not create mock screenshots or alter test output. If a step fails, record the error and fix it before marking the checklist complete.

## 5. Student-authored reflection required

Complete the final section of `Documentation/CHALLENGES_AND_LEARNINGS.md` in your own words. A useful structure is:

- The most difficult technical issue you personally encountered.
- The exact error or unexpected behaviour you observed.
- The debugging steps you actually used (logs, breakpoints, test cases, terminal commands, etc.).
- The change you made and how you checked it.
- What you learned about data structures, graph algorithms, asynchronous programming or software architecture.
- What you would improve if you had another development iteration.

Do not claim a debugging step, meeting, lecturer comment or personal experience that did not happen.

## 6. Exact feedback evidence required

Open the original formative feedback document and paste the lecturer's exact wording into the table in `Documentation/ITERATIVE_FEEDBACK_LEDGER.md`. For each comment, add:

- the corresponding feedback-ledger ID;
- the source file/method changed;
- the test or manual evidence demonstrating the change;
- whether the item is verified or still pending.

The ZIP used to assemble this POE did not include the original formative feedback PDF, so exact lecturer wording cannot be completed from the available files.

## 7. Suggested final demonstration order

1. Explain the desktop/API architecture and show the API health endpoint.
2. Show the four modules in the main menu.
3. Demonstrate normal and critical telemetry processing.
4. Query telemetry using a device and date range; explain AVL indexing and inclusive bounds.
5. Explain the AVL rotations and show the regression test output.
6. Show the topology tree and graph.
7. Run BFS and DFS and explain their visit order.
8. Run Prim's algorithm and explain the composite edge cost and simulated-metric flag.
9. Demonstrate a device command and undo.
10. Finish with the test results, architecture limitations and justified future recommendations.

## 8. Final submission checklist

- [ ] Extract and test this exact final ZIP on Windows with .NET 10.
- [ ] Build succeeds for desktop, API and test projects.
- [ ] All 10 regression tests pass.
- [ ] All four desktop modules have been manually opened and demonstrated.
- [ ] API health endpoint has been checked.
- [ ] Required screenshots have been captured in `Evidence/`.
- [ ] Personal reflection is complete and truthful.
- [ ] Exact lecturer feedback has been pasted into the feedback ledger.
- [ ] README and report match the final source code.
- [ ] Repository link/access has been checked if the lecturer requires Git history.
