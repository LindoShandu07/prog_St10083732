using Microsoft.AspNetCore.Mvc;
using SystemXsystem_API.Models;
using SystemXsystem_API.Services;

namespace SystemXsystem_API.Controllers;

[ApiController]
[Route("api/devices")]
public class DevicesController : ControllerBase
{
    private readonly SmartXDataStore _store;
    public DevicesController(SmartXDataStore store) => _store = store;

    [HttpGet]
    public ActionResult<List<Device>> GetAll() => _store.GetDevices();

    [HttpPost]
    public IActionResult Register([FromBody] Device device)
    {
        if (string.IsNullOrWhiteSpace(device.Id) || string.IsNullOrWhiteSpace(device.Name))
            return BadRequest(new { error = "Id and Name are required." });
        if (!_store.RegisterDevice(device))
            return Conflict(new { error = $"Device '{device.Id}' already exists." });
        return Ok(device);
    }

    [HttpPost("seed")]
    public IActionResult Seed()
    {
        _store.SeedDemoDevices();
        return Ok(new { devices = _store.GetDevices().Count });
    }

    [HttpPost("{id}/disconnect")]
    public IActionResult Disconnect(string id)
    {
        _store.Disconnect(id);
        return Ok();
    }
}

[ApiController]
[Route("api/telemetry")]
public class TelemetryController : ControllerBase
{
    private readonly SmartXDataStore _store;
    public TelemetryController(SmartXDataStore store) => _store = store;

    [HttpPost]
    public IActionResult Post([FromBody] TelemetryRequest request)
    {
        var (packet, error) = _store.Ingest(request);
        if (packet == null) return BadRequest(new { error });
        return Accepted(new
        {
            queued = packet.IsCritical ? "priority" : "standard",
            packet.IsCritical,
            packet.Reason
        });
    }

    [HttpGet("history")]
    public ActionResult<List<TelemetryPacket>> History([FromQuery] string? deviceId, [FromQuery] int take = 50,
        [FromQuery] DateTime? fromUtc = null, [FromQuery] DateTime? toUtc = null)
    {
        if (fromUtc.HasValue && toUtc.HasValue && fromUtc.Value > toUtc.Value)
            return BadRequest(new { error = "fromUtc must be earlier than or equal to toUtc." });
        return _store.GetHistory(deviceId, Math.Clamp(take, 1, 5000), fromUtc?.ToUniversalTime(), toUtc?.ToUniversalTime());
    }
}

[ApiController]
[Route("api/commands")]
public class CommandsController : ControllerBase
{
    private readonly SmartXDataStore _store;
    public CommandsController(SmartXDataStore store) => _store = store;

    [HttpPost]
    public IActionResult Execute([FromBody] CommandRequest request)
    {
        var (log, error) = _store.ExecuteCommand(request);
        if (log == null) return BadRequest(new { error });
        return Ok(log);
    }

    [HttpPost("undo")]
    public IActionResult Undo()
    {
        var log = _store.Undo();
        if (log == null) return NotFound(new { error = "Nothing to undo." });
        return Ok(log);
    }

    [HttpGet("history")]
    public ActionResult<List<CommandLog>> History() => _store.GetCommandHistory();
}

[ApiController]
[Route("api/topology")]
public class TopologyController : ControllerBase
{
    private readonly SmartXDataStore _store;
    public TopologyController(SmartXDataStore store) => _store = store;

    [HttpGet]
    public ActionResult<TopologyResponse> Get() => _store.GetTopology();
}

[ApiController]
[Route("api/insights")]
public class InsightsController : ControllerBase
{
    private readonly InsightEngine _engine;
    private readonly SmartXDataStore _store;

    public InsightsController(InsightEngine engine, SmartXDataStore store)
    {
        _engine = engine;
        _store = store;
    }

    [HttpGet]
    public ActionResult<List<Insight>> Get() => _engine.Generate();

    /// <summary>Records a search so the engine can learn what the operator looks for after alerts.</summary>
    [HttpPost("search")]
    public ActionResult<List<Device>> Search([FromBody] SearchRequest request) => _store.RecordSearch(request.Query);
}

[ApiController]
[Route("api/dashboard")]
public class DashboardController : ControllerBase
{
    private readonly SmartXDataStore _store;
    public DashboardController(SmartXDataStore store) => _store = store;

    [HttpGet]
    public ActionResult<DashboardSummary> Summary()
    {
        _store.ProcessPending(); // make sure the numbers shown are current
        return _store.GetSummary();
    }

    [HttpGet("notifications")]
    public ActionResult<List<Notification>> Notifications([FromQuery] int since = 0) => _store.GetNotifications(since);
}


[ApiController]
[Route("api/topology/algorithms")]
public class TopologyAlgorithmsController : ControllerBase
{
    private readonly SmartXDataStore _store;
    private readonly NetworkGraphService _graphs;
    public TopologyAlgorithmsController(SmartXDataStore store, NetworkGraphService graphs) { _store = store; _graphs = graphs; }

    private NetworkGraph CurrentGraph() => _graphs.BuildGraph(_store.GetTopology());

    [HttpGet("tree")]
    public ActionResult<NetworkTreeNode> Tree() => _graphs.BuildTree(_store.GetTopology());

    [HttpGet("graph")]
    public ActionResult<NetworkGraph> Graph() => CurrentGraph();

    [HttpGet("traverse")]
    public ActionResult<NetworkTraversalResult> Traverse([FromQuery] string startNode = "gateway", [FromQuery] string method = "BFS")
    {
        try { return _graphs.Traverse(CurrentGraph(), startNode, method); }
        catch (ArgumentException ex) { return BadRequest(new { error = ex.Message }); }
    }

    [HttpGet("mst")]
    public ActionResult<MinimumSpanningTreeResult> MinimumSpanningTree() => _graphs.MinimumSpanningTree(CurrentGraph());
}
