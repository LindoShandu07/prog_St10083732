namespace SystemXsystem1;

/// <summary>Real-Time Command Stream: search, send overrides, undo, and watch actuator states change.</summary>
public class CommandPanel : ModulePanel
{
    private class TargetItem
    {
        public string Label { get; init; } = "";
        public string Value { get; init; } = "";
        public override string ToString() => Label;
    }

    private readonly TextBox _searchBox = new();
    private readonly Label _searchResult = new();
    private readonly ComboBox _targetBox = new();
    private readonly Label _commandStatus = new();
    private readonly ListView _states = new();
    private readonly ListBox _history = new();

    private List<DeviceDto> _devices = new();
    private string _targetKey = "";

    public CommandPanel(ApiClient api) : base(api)
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = Theme.Bg };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 120));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 130));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        root.Controls.Add(BuildSearchCard(), 0, 0);
        root.Controls.Add(BuildCommandCard(), 0, 1);

        var bottom = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Theme.Bg };
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
        bottom.Controls.Add(BuildStatesCard(), 0, 0);
        bottom.Controls.Add(BuildHistoryCard(), 1, 0);
        root.Controls.Add(bottom, 0, 2);

        Controls.Add(root);
    }

    private Panel BuildSearchCard()
    {
        var card = Theme.MakeCard("Search devices");
        var row = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, BackColor = Theme.Card };
        _searchBox.Width = 360;
        _searchBox.PlaceholderText = "Name, id, type or zone, e.g. Pump A";
        _searchBox.KeyDown += async (_, e) =>
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; await SearchAsync(); }
        };
        var searchButton = Theme.MakeButton("Search", true, 100);
        searchButton.Click += async (_, _) => await SearchAsync();
        _searchResult.AutoSize = true;
        _searchResult.Font = Theme.Small;
        _searchResult.Margin = new Padding(10, 8, 0, 0);
        row.Controls.AddRange(new Control[] { _searchBox, searchButton, _searchResult });
        card.Controls.Add(row);
        card.Controls.SetChildIndex(row, 0);
        return card;
    }

    private Panel BuildCommandCard()
    {
        var card = Theme.MakeCard("Send override command");
        var row = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, BackColor = Theme.Card };
        _targetBox.DropDownStyle = ComboBoxStyle.DropDownList;
        _targetBox.Width = 280;
        var onButton = Theme.MakeButton("Turn ON", true, 100);
        var offButton = Theme.MakeButton("Turn OFF", false, 100);
        var undoButton = Theme.MakeButton("Undo last", false, 110);
        onButton.Click += async (_, _) => await SendCommandAsync("ON");
        offButton.Click += async (_, _) => await SendCommandAsync("OFF");
        undoButton.Click += async (_, _) => await UndoAsync();
        row.Controls.AddRange(new Control[] { _targetBox, onButton, offButton, undoButton });

        _commandStatus.Dock = DockStyle.Top;
        _commandStatus.Height = 24;
        _commandStatus.Font = Theme.Small;

        card.Controls.Add(row);
        card.Controls.Add(_commandStatus);
        card.Controls.SetChildIndex(row, 0);
        return card;
    }

    private Panel BuildStatesCard()
    {
        var card = Theme.MakeCard("Actuator states (live)");
        _states.Dock = DockStyle.Fill;
        _states.View = View.Details;
        _states.FullRowSelect = true;
        _states.BorderStyle = BorderStyle.None;
        _states.HeaderStyle = ColumnHeaderStyle.Nonclickable;
        _states.Columns.Add("Device", 170);
        _states.Columns.Add("Zone", 130);
        _states.Columns.Add("Type", 90);
        _states.Columns.Add("State", 110);
        card.Controls.Add(_states);
        card.Controls.SetChildIndex(_states, 0);
        return card;
    }

    private Panel BuildHistoryCard()
    {
        var card = Theme.MakeCard("Command stream (newest first)");
        _history.Dock = DockStyle.Fill;
        _history.BorderStyle = BorderStyle.None;
        _history.IntegralHeight = false;
        card.Controls.Add(_history);
        card.Controls.SetChildIndex(_history, 0);
        return card;
    }

    // ------------------------------------------------------------ actions

    private async Task SearchAsync()
    {
        string query = _searchBox.Text.Trim();
        if (query.Length == 0) return;
        try
        {
            var matches = await Api.PostAsync<List<DeviceDto>>("/api/insights/search", new { query });
            if (matches.Count == 0)
                SetStatus(_searchResult, "No devices match.", "warning");
            else
                SetStatus(_searchResult, string.Join("   |   ", matches.Take(4).Select(d => $"{d.Name}: {Theme.DeviceStateText(d)}")), "info");
        }
        catch (ApiException ex) { SetStatus(_searchResult, ex.Message, "critical"); }
    }

    private async Task SendCommandAsync(string command)
    {
        if (_targetBox.SelectedItem is not TargetItem target)
        {
            SetStatus(_commandStatus, "Pick a target first (load demo devices on the Dashboard if the list is empty).", "warning");
            return;
        }

        try
        {
            var log = await Api.PostAsync<CommandLogDto>("/api/commands", new { target = target.Value, command });
            SetStatus(_commandStatus, $"{command} sent to {target.Label} ({log.PreviousStates.Count} device(s)).", "success");
            await RefreshAsync();
        }
        catch (ApiException ex) { SetStatus(_commandStatus, ex.Message, "critical"); }
    }

    private async Task UndoAsync()
    {
        try
        {
            var log = await Api.PostAsync<CommandLogDto>("/api/commands/undo");
            SetStatus(_commandStatus, $"Undid {log.Command} on {FriendlyTarget(log.Target)}.", "warning");
            await RefreshAsync();
        }
        catch (ApiException ex) { SetStatus(_commandStatus, ex.Message, "warning"); }
    }

    private string FriendlyTarget(string target)
    {
        if (target == "*") return "all actuators";
        if (target.StartsWith("type:", StringComparison.OrdinalIgnoreCase)) return "all " + target.Substring(5) + "s";
        var device = _devices.FirstOrDefault(d => string.Equals(d.Id, target, StringComparison.OrdinalIgnoreCase));
        return device?.Name ?? target;
    }

    // ------------------------------------------------------------ refresh

    public override async Task RefreshAsync()
    {
        _devices = await Api.GetAsync<List<DeviceDto>>("/api/devices");
        var actuators = _devices.Where(d => d.IsActuator).ToList();

        // Target list (rebuilt only when the set of actuators changes so the selection stays put).
        string key = string.Join(",", actuators.Select(a => a.Id));
        if (key != _targetKey)
        {
            string? previous = (_targetBox.SelectedItem as TargetItem)?.Value;
            _targetKey = key;
            _targetBox.Items.Clear();
            if (actuators.Count > 0)
            {
                _targetBox.Items.Add(new TargetItem { Label = "All actuators", Value = "*" });
                _targetBox.Items.Add(new TargetItem { Label = "All valves", Value = "type:Valve" });
                _targetBox.Items.Add(new TargetItem { Label = "All pumps", Value = "type:Pump" });
                _targetBox.Items.Add(new TargetItem { Label = "All smart plugs", Value = "type:SmartPlug" });
                foreach (var a in actuators)
                    _targetBox.Items.Add(new TargetItem { Label = $"{a.Name} ({a.Zone})", Value = a.Id });
                int index = _targetBox.Items.Cast<TargetItem>().ToList().FindIndex(t => t.Value == previous);
                _targetBox.SelectedIndex = index >= 0 ? index : 0;
            }
        }

        _states.BeginUpdate();
        _states.Items.Clear();
        foreach (var a in actuators)
        {
            var item = new ListViewItem(a.Name);
            item.SubItems.Add(a.Zone);
            item.SubItems.Add(a.Type);
            item.SubItems.Add(a.State);
            item.ForeColor = a.State == "ON" ? Theme.Success : a.State == "DISCONNECTED" ? Theme.Critical : Theme.Muted;
            _states.Items.Add(item);
        }
        _states.EndUpdate();

        var history = await Api.GetAsync<List<CommandLogDto>>("/api/commands/history");
        _history.BeginUpdate();
        _history.Items.Clear();
        foreach (var h in history)
            _history.Items.Add($"{h.Timestamp.ToLocalTime():HH:mm:ss}   #{h.Id}   {h.Command}  ->  {FriendlyTarget(h.Target)}");
        if (history.Count == 0) _history.Items.Add("No commands sent yet.");
        _history.EndUpdate();
    }
}
