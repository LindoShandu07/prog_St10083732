# SystemXSystem POE — Start Here

**Module:** Programming 3B (PROG7312)  
**Project:** Smart-X Network Monitoring and Management System  
**Student name in project materials:** Lindokuhle Mbatha  
**Framework:** .NET 10  
**Client:** Windows Forms  
**Backend:** ASP.NET Core Web API

## What is included

- `SystemXsystem.sln` — Visual Studio solution.
- `SystemXsystem1/` — Windows Forms desktop client and four integrated modules.
- `SystemXsystem_API/` — ASP.NET Core API, data store, telemetry processing, AVL history index and graph algorithms.
- `SystemXsystem_API.Tests/` — dependency-free regression test runner.
- `Documentation/` — implementation report, challenge/learning report, technology recommendations, graph improvements, feedback ledger, architecture diagram and final verification checklist.
- `README.md` — full project setup, operation and technical overview.
- `POE_SUBMISSION_GUIDE.md` — rubric mapping and final submission checklist.
- `Run-SmartX.bat` — convenience launcher for Windows.

## Quick start (Windows)

1. Install the .NET 10 SDK and the Windows Desktop Runtime.
2. Extract the entire `SystemXSystem_POE` folder to a location you can write to.
3. Open PowerShell in `SystemXSystem_POE`.
4. Restore, build and run the regression suite:

```powershell
dotnet restore .\SystemXsystem.sln
dotnet build .\SystemXsystem.sln
dotnet run --project .\SystemXsystem_API.Tests\SystemXsystem_API.Tests.csproj
```

5. Start the API in one PowerShell window:

```powershell
dotnet run --project .\SystemXsystem_API\SystemXsystem_API.csproj
```

6. In a second PowerShell window, start the desktop client:

```powershell
dotnet run --project .\SystemXsystem1\SystemXsystem1.csproj
```

7. Check `http://localhost:5000/api/health` in a browser. The desktop client should report that it is connected.

## Before submitting

Read `POE_SUBMISSION_GUIDE.md` and complete every item marked as student action. In particular, add your own truthful reflection, insert the exact lecturer feedback wording into the feedback ledger, and capture screenshots from your own final build. The package records a student-reported successful build and 10/10 test run from the previous Criterion 2 version; rerun the commands above against this exact extracted final folder before submission.
